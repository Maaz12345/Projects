<?php


//if (isset($_POST['submit'])) {
    //echo "<script>alert(\"Login page still under construction\");</script>";
   
    $servername = "localhost";
  $username = "root";
  $password = "12345";
  $db= "mydb";

  // Create connection
  $conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
        $bool = false;
    } else {
        $bool = true;
   //         echo "<p>Connected successfully 11</p>"; 
    }


   
    

   

     $name=isset($_POST['input_name']) ? $_POST['input_name'] : '';
  $email = isset($_POST['input_email']) ? $_POST['input_email'] : '';
  $password = isset($_POST['input_password']) ? $_POST['input_password'] : '';

//if(isset($_POST['inputEmail1'])){$Email = $_POST['inputEmail1']; }

  //echo $email;
 //echo $name;
 //echo $password;
//if(isset($_POST['price'])){ $price = $_POST['price']; } 
//if(isset($_POST['description'])){ $description = $_POST['description']; } 

  //          $Email = $_POST["inputEmail1"];
    //        $Password1 = $_POST["inputPassword1"];
 //INSERT INTO `mydb`.`user` (`id`, `role`, `email`, `password`) VALUES ('1', '1', 'xyz@hotmail.com', '12345');
 //$sql = "INSERT INTO `mydb`.`user` (`ID`, `ROLE`, `NAME`, `EMAIL`, `PASSWORD`) VALUES (NULL, \'1\', \'Khaala\', \'hussain_iraani@hotmail.com\', \'thandi\');";
         if ( empty($name) || empty($email) || empty($password) ) {
        echo "<script>alert(\"All fields are required\");</script>";
      } else {
                


 $query = " SELECT * FROM user WHERE EMAIL = '$email' ";
           $result = $conn->query($query);
          
           $count = mysqli_num_rows($result);
         
                
               if ($count == 1) {
                  echo "<script>alert(\"Please enter a different Email.\");</script>"; 
                }
                 else {
                
                $query1 = " INSERT INTO user (`ID`, `ROLE`, `NAME`, `EMAIL`, `PASSWORD`) VALUES (NULL, '1', '$name','$email', '$password');";
    
                if ($result1 = $conn->query($query1)) {
                  echo "<script>alert(\"Record added to database successfully.\");</script>";
                    
                } 
                else 
                {

                    echo "<script>alert(\"Failed to add record\");</script>";
                   // echo "Failed to add record.";
                }
               // $conn->close();
                }
           }
           // $query = " INSERT INTO user (`ID`, `ROLE`, `NAME`, `EMAIL`, `PASSWORD`) VALUES (NULL, '1', '$name','$email', '$password'); ";
           //$result = $conn->query($query);
          
           
         // if ($count==1)
          //  echo "registered ";
        //else 
         //   echo "not registered";

//}
           
           ?>