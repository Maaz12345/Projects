<pre>
DEBUG:
<?php
require_once 'connection.php';

    
$query="select max(id) as UID from user";
$result = $conn->query($query);
$count = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
$uid=$row["UID"]+1;
//image

error_reporting(E_ALL);
ini_set("display_errors",1);
$success = 0;
$fail = 0;
$imagearray=array();    
$uploads_dir = 'uploads';
mkdir($uploads_dir."/".$uid, 0700);
$uploads_dir =$uploads_dir."/".$uid;
$count = 1;
foreach ($_FILES["userfile"]["error"] as $key => $error) {
    if ($error == UPLOAD_ERR_OK) {
        $tmp_name = $_FILES["userfile"]["tmp_name"][$key];
        $name = $_FILES["userfile"]["name"][$key];
        $uploadfile = "$uploads_dir/$name";
        $ext = strtolower(substr($uploadfile,strlen($uploadfile)-3,3));
        if (preg_match("/(jpg|gif|png|bmp)/",$ext)){
            echo $count;
            
            $newfile = "$uploads_dir/".str_pad($count,2,'0',STR_PAD_LEFT).".".$ext;
            $imagearray[$count]=$newfile;
            $count++;
            if(move_uploaded_file($tmp_name, $newfile)){
                $success++;
            }else{
                echo "Couldn't move file: Error Uploading the file. Retry after sometime.\n";
                $fail++;
            }
        }else{
            echo "Invalid Extension.\n";
            $fail++;
        }
    }
}
echo "<br> Number of files Uploaded:".$success;
echo "<br> Number of files Failed:".$fail;

?>
</pre>