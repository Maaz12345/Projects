<?php
include_once 'header.php';
?>

	<!-- Header -->
	<header>
		<section class="call-to-action text-center">
      <div class="text-all">
        <h2 class="title">Theme Wagon Advisors</h2>
        <h3 class="subtitle">Make sure your business succeeds in 2015.</h3>
        <button class="infos-button">Get Informations</button>
      </div>  
    </section> 
  </header>

	<!-- /Header -->

  <section class="container about-content">
    <h3 class="cta-text text-center">Proudly part of the worlds most elite Internet Marketers & SEO Experts.</h3><br>
    <div class="col-lg-6 col-sm-12 col-md-6">
      <p class="lead">Metal </p>
      <div class="pro-bar-container color-nephritis">
        <div class="pro-bar bar-100 color-emerald" data-pro-bar-percent="100">
          <div class="pro-bar-candy candy-ltr"></div>
        </div>
      </div>
      <p class="lead">Rock </p>
      <div class="pro-bar-container color-nephritis">
        <div class="pro-bar bar-90 color-emerald" data-pro-bar-percent="90" data-pro-bar-delay="100">
          <div class="pro-bar-candy candy-ltr"></div>
        </div>
      </div>
      <p class="lead">Alternative rock </p>
      <div class="pro-bar-container color-nephritis">
        <div class="pro-bar bar-80 color-emerald" data-pro-bar-percent="80" data-pro-bar-delay="200">
          <div class="pro-bar-candy candy-ltr"></div>
        </div>
      </div>
      <p class="lead">Thrash Metal </p>
      <div class="pro-bar-container color-nephritis">
        <div class="pro-bar bar-70 color-emerald" data-pro-bar-percent="70" data-pro-bar-delay="300">
          <div class="pro-bar-candy candy-ltr"></div>
        </div>
      </div>
      <p class="lead">Folk </p>
      <div class="pro-bar-container color-nephritis">
        <div class="pro-bar bar-60 color-emerald" data-pro-bar-percent="60" data-pro-bar-delay="400">
          <div class="pro-bar-candy candy-ltr"></div>
        </div>
      </div>
    </div>
    <div class="col-lg-6 col-sm-12 col-md-6">
      <p class="about-text">
        Theme Wagon Advisors Search Engine Marketing is a leading internet marketing agency based out of the beautiful Southern Oregon. We have one simple mission. Guide our clients to reach peak profits. Going above and beyond we’ve developed a specialized team of SEO experts, Web Developers, Social Media Strategists, Lead Generating Professionals & Conversion Optimization specialists.
        MMA is a proud part of the worlds most elite Internet Marketers & SEO Experts.
        Which allows us to have constant success where other cookie cutter companies have failed. Pride built on transparency with our customers & getting results. Unlike most companies, we guarantee results.Pride built on transparency with our customers & getting results. Unlike most companies, we guarantee results.
      </p>  
    </div>
  </section>

  <section class="portfolio">
    <h3 class="cta-text text-center">The Theme Wagon</h3><hr>
     <div class="container">
     <div class="item-section col-md-6">
          <div class="icon text-center">
            <img src="assets/images/zah.jpg" alt="Photo">
          </div>
          <h4 class="item-title text-center">Zaheer Abbas</h4>
          <p class="portfoio-text">For the past 5 years Travis has been creating his own successful, high profit generating website & products that have given him the ability to study SEO and master Search Engine Optimization. Working with clients Travis has honed in on exactly what it takes to get the results beyond what you expect, and create the brand you need to succeed. Simply put he has the skill it takes to impact your bottom line and has helped bring in millions.</p>
     </div>
     <div class="item-section col-md-6">
          <div class="icon text-center">
            <img src="assets/images/kk.jpg" alt="Photo">
          </div>
          <h4 class="item-title text-center">Khizar Khalifa</h4>
          <p class="portfoio-text">For the past 5 years Travis has been creating his own successful, high profit generating website & products that have given him the ability to study SEO and master Search Engine Optimization. Working with clients Travis has honed in on exactly what it takes to get the results beyond what you expect, and create the brand you need to succeed. Simply put he has the skill it takes to impact your bottom line and has helped bring in millions.</p>
     </div>
    </div>
  </section>

  <section class="call-to-action text-center">
    <div class="text-all">
      <h2 class="title">Theme Wagon Advisors</h2>
      <button class="infos-button">Get Informations</button>
    </div>    
  </section>

<?php
  include_once 'footer.php';
  ?>
