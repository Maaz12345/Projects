<?php
//include_once 'header.php';
require_once 'connection.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="free-educational-responsive-web-template-webEdu">
  <meta name="author" content="webThemez.com">
  <title>Search Karachi</title>
  <link rel="favicon" href="assets/images/favicon.png">
  <link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/font-awesome.min.css"> 
  <link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen"> 
  <link rel="stylesheet" href="assets/css/style.css">
    <link rel='stylesheet' id='camera-css'  href='assets/css/camera.css' type='text/css' media='all'> 
  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="assets/js/html5shiv.js"></script>
  <script src="assets/js/respond.min.js"></script>
  <![endif]-->
</head>
<body>
	<!-- Header -->
	<header id="head">
		<div class="container">
             <div class="heading-text">						
              <h1 class="animated flipInY delay1">Search Places in Karachi </h1> 
     
   <form method="post"  action="testimonial.php" enctype="multipart/form-data" >
                                  <div class="form_row">
                                    <label class="field_name align_right"><font size="4" color="black"><b>Select Area</b></font></label>
                                    <div class="field">
                                        <div class="span4 no-search">
                                            <select style="color:gray" name='Name' class="chosen">
                                            
                                            <?php
                                            $sql = "SELECT AName FROM area";
                                            $result = mysqli_query($conn,$sql);

                                            while ($row = mysqli_fetch_array($result)) {
                                                  $fn=$row['AName'];
                                                  ?>
                                                  <option style="color:gray" value="<?php echo  $fn;?>"><?php echo  $fn; ?> </option>
                                                  <?php
                                            }
                                            ?>
                                            </select>
                                        </div>
                                    </div>

                                    <label class="field_name align_right"><font size="4" color="black"><b>Select Category</font></label>
                                    <div class="field">
                                        <div class="span4 no-search">
                                            <select style="color:gray" name='Name1' class="chosen">
                                            
                                            <?php
                                            $sql = "SELECT CName FROM category";
                                            $result = mysqli_query($conn,$sql);

                                            while ($row = mysqli_fetch_array($result)) {
                                                  $fn=$row['CName'];
                                                  ?>
                                                  <option style="color:gray" value="<?php echo  $fn;?>"><?php echo  $fn; ?> </option>
                                                  <?php
                                            }
                                            ?>
                                            </select>

                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="form_row">
                                    <div class="field">
                                        <input type="submit" value="SEARCH" name="PlaceSubmit" class="infos-button">
                                    </div>
                                    <br><a href="contact.php" class="btn btn-info" role="button">Add Your Place</a>
                                </div>
                                
                                
              <!--<button class="infos-button">Get Informations</button>-->
						</div>
          </form>
            
			       <div class="fluid_container">                       
                <div class="camera_wrap camera_emboss pattern_1" id="camera_wrap_4">
                    <div data-thumb="assets/images/slides/thumbs/khi1.jpg" data-src="assets/images/slides/khi2.jpg">
                    </div> 
                    <div data-thumb="assets/images/slides/thumbs/khi2.jpg" data-src="assets/images/slides/khi1.jpg">
                    </div>
                    <div data-thumb="assets/images/slides/thumbs/khi3.jpg" data-src="assets/images/slides/khi3.jpg">
                    </div> 

                </div><!-- #camera_wrap_3 -->

              </div><!-- .fluid_container -->
      		  </div>
      	 </header>
	

  <!--<section class="call-to-action text-center">
    <div class="text-all">
      <div class="form_row">
                                    <label class="field_name align_right">Select Area</label>
                                    <div class="field">
                                        <div class="span4 no-search">
                                            <select name="AreaName" class="chosen">
                     
                                            </select>
                                        </div>
                                    </div>

                                    <label class="field_name align_right">Select Category</label>
                                    <div class="field">
                                        <div class="span4 no-search">
                                            <select name="CatName" class="chosen">
                     
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <button class="infos-button">SEARCH</button>
    </div>  
  </section>-->

  <?php
  include_once 'footer.php';
  ?>
