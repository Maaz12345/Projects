<?php
//include_once 'header.php';
require_once 'connection.php';
?>

	<!-- Header -->
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="free-educational-responsive-web-template-webEdu">
    <meta name="author" content="webThemez.com">
    <title>Search Karachi</title>
    <link rel="favicon" href="assets/images/favicon.png">
    <link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css"> 
    <link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen"> 
    <link rel="stylesheet" href="assets/css/style.css">
      <link rel='stylesheet' id='camera-css'  href='assets/css/camera.css' type='text/css' media='all'> 
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="assets/js/html5shiv.js"></script>
    <script src="assets/js/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	<header>
		  <section class="call-to-action text-center">
        <div class="text-all">
          <h2 class="title">Add Your Place</h2>
          <!--<h3 class="subtitle">Make sure your business succeeds in 2015.</h3>
          <button class="infos-button">Get Information</button>-->
        </div>  
    </section> 
  </header>
	<!-- /Header -->
      <!--<section class="map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2825.211958629328!2d91.83379900000003!3d24.909438007883935!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x37505558dd0be6a1%3A0x65c7e47c94b6dc45!2sTechnext!5e1!3m2!1sen!2s!4v1425297675833" width="100%" height="450" frameborder="0" style="border:0">
          </iframe>
      </section>-->
      <section class="contacts container">
        <div class="contact-form-full col-md-offset-1 col-md-5 col-sm-6 col-xs-12">

              <div class="inner contact">
                <!-- Form Area -->
                <div class="contact-form">
                    <!-- Form -->
                    <form id="contact-us" method="post" action="get.php">
                        <!-- Left Inputs -->
                        <div class="col-xs-12 wow animated slideInLeft" data-wow-delay=".5s">
                            <!-- Name -->
                            <input type="text" name="name" id="name" required="required" class="form" placeholder="Place Name" />
                            <!-- Email -->
                            <input type="text" name="contact" id="name" required="required" class="form" placeholder="Contact No" />
                            <!-- Address -->
                            <input type="text" name="address" id="name" required="required" class="form" placeholder="Address" />
                            <!--Area -->
                            <div class="field">
                                <div class="span4 no-search">
                                    <select required="required" style="color:gray" name='AName' class="chosen">
                                    <option style="color:gray" value="Select Category">Select Area</option>
                                    <?php
                                    $sql = "SELECT AName FROM area";
                                    $result = mysqli_query($conn,$sql);

                                    while ($row = mysqli_fetch_array($result)) {
                                          $fn=$row['AName'];
                                          ?>
                                          <option style="color:gray" value="<?php echo  $fn;?>"><?php echo  $fn; ?> </option>
                                          <?php
                                    }
                                    ?>
                                    </select>
                                </div>
                            </div>

                            <!--Category -->
                            <br><div class="field">
                                <div class="span4 no-search">
                                    <select required style="color:gray" name='CName' class="chosen">
                                    <option style="color:gray" value="Select Category">Select Category</option>
                                    <?php
                                    $sql = "SELECT CName FROM category";
                                    $result = mysqli_query($conn,$sql);

                                    while ($row = mysqli_fetch_array($result)) {
                                          $fn=$row['CName'];
                                          ?>
                                          <option style="color:gray" value="<?php echo  $fn;?>"><?php echo  $fn; ?> </option>
                                          <?php
                                    }
                                    ?>
                                    </select>

                                    
                                </div>
                            </div>

                        </div><!-- End Left Inputs -->
                        <!-- Right Inputs -->
                        <div class="col-xs-12 wow animated slideInRight" data-wow-delay=".5s">
                            <!-- Message -->
                            <br><textarea name="description" id="message" class="form textarea"  placeholder="Description"></textarea>
                        </div><!-- End Right Inputs -->
                        <!-- Bottom Submit -->
                        <div class="relative fullwidth col-xs-12">
                            <!-- Send Button -->
                            <button type="submit" id="submit" name="submit" class="form-btn semibold">Submit</button>
                        </div><!-- End Bottom Submit -->
                        <!-- Clear -->
                        <div class="clear"></div>
                    </form>

                    <!-- Your Mail Message -->
                    <div class="mail-message-area">
                        <!-- Message -->
                        
                    </div>

                </div><!-- End Contact Form Area -->
            </div><!-- End Inner -->
          </div>
          
      </section>

<?php
  include_once 'footer.php';
?>
