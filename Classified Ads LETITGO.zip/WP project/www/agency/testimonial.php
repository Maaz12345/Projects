<?php
//include_once 'header.php';
require_once 'connection.php';
?>

<?php
if(isset($_POST['PlaceSubmit']))
{
  $q1= $_POST["Name"];
  $q2= $_POST["Name1"];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="free-educational-responsive-web-template-webEdu">
  <meta name="author" content="webThemez.com">
  <title>Search Karachi</title>
  <link rel="favicon" href="assets/images/favicon.png">
  <link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/font-awesome.min.css"> 
  <link rel="stylesheet" href="assets/css/bootstrap-theme.css" media="screen"> 
  <link rel="stylesheet" href="assets/css/style.css">
    <link rel='stylesheet' id='camera-css'  href='assets/css/camera.css' type='text/css' media='all'> 
  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
  <script src="assets/js/html5shiv.js"></script>
  <script src="assets/js/respond.min.js"></script>
  <![endif]-->
</head>
<body>

	<!-- Header -->
	<header>
		  <section class="call-to-action text-center">
        <div class="text-all">
          <h2 class="title"><?php echo "$q1";?></h2>
          <h3 class="subtitle"><?php echo "$q2";?></h3>
        </div>  
    </section> 
  </header>


  
    <?php
    $rec_limit = 10;
    $sql= "SELECT count(Id) FROM place";
    $result=mysqli_query($conn,$sql);
    $row = mysqli_fetch_array($result, MYSQL_NUM );
    $rec_count = $row[0];
    //echo "<br/>Data-->".$q1.$q2;

    $sql= "SELECT * FROM place p, category c, area a where p.category_Id=c.Id and p.area_Id=a.Id and a.AName='$q1' and c.CName='$q2'";
    $result=mysqli_query($conn,$sql);

    if( isset($_GET{'page'} ) )
         {
            $page = $_GET{'page'} + 1;
            $offset = $rec_limit * $page ;
         }
         else
         {
            $page = 0;
            $offset = 0;
         }
         $left_rec = $rec_count - ($page * $rec_limit);
         $sql = "SELECT * FROM place p, category c, area a where p.category_Id=c.Id and p.area_Id=a.Id and a.AName='$q1' and c.CName='$q2'".
            "LIMIT $offset, $rec_limit";
            
         $retval = mysqli_query( $conn, $sql );
         
         if(! $retval )
         {
            die('Could not get data: ' . mysql_error());
         }
    
    //$num_rows = mysqli_num_rows($result);
    //echo "$num_rows Rows\n";
      //<script type="Society Created/javascript">;
      //echo "<script>alert('Success!');</script>";
    while ($row = mysqli_fetch_array($retval)) 
    {
          $pname=$row['Name'];
          $pdesc=$row['Descrip'];
          $paddress=$row['Address'];
          $pcontact=$row['Contact'];
    ?>
   <section>
          <!--<summary><?php echo "$pname"; ?></summary>-->
        <b><ul style="text-align:center;">
          <li style="font-family:Gadget;"><?php echo "$pname"; ?></li>
          <li>Description: <?php echo "$pdesc"; ?></li>
          <li>Address: <?php echo "$paddress"; ?></li>
          <li>Contact No: <?php echo "$pcontact"; ?></li>
        </ul></b>
    </section>
        <?php
    }
    if( $page > 0 )
         {
            $last = $page - 2;
            echo "<a href=\"$_PHP_SELF?page=$last\">Last 10 Records</a> |";
            echo "<a href=\"$_PHP_SELF?page=$page\">Next 10 Records</a>";
         }
         
         else if( $page == 0 )
         {
            //echo "<a href=\"$_PHP_SELF?page=$page\">Next 10 Records</a>";
      }
      
         else if( $left_rec < $rec_limit )
         {
            $last = $page - 2;
            echo "<a href=\"$_PHP_SELF?page=$last\">Last 10 Records</a>";
         }

    ?>
     

	<!-- /Header -->
 

  <!--<section class="call-to-action text-center">
    <div class="text-all">
      <h2 class="title">Theme Wagon Advisors</h2>
      <button class="infos-button">Get Informations</button>
    </div>   
  </section>-->
  <?php
  include_once 'maps.php';
  ?>

<?php
  include_once 'footer.php';
  ?>
