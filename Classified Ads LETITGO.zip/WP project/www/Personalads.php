	<?php


	include_once 'header.php';
	

	?>
	<!-- Header End====================================================================== -->

	<div id="mainBody">
	<div class="container">
		<div class="row">
	<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
          <!--<div class="well well-small"><a id="myCart" href="product_summary.php"><img src="themes/images/ico-cart.png" alt="cart">3 Items in your cart  <span class="badge badge-warning pull-right">$155.00</span></a></div>-->
          <ul id="sideManu" class="nav nav-tabs nav-stacked">
          <label>Select the category please</label>
               <li class="subMenu open"><a> Vehicles</a>
                    <ul>
                    <li><a <class="active" href="products.php?cat1=1"><i class="icon-chevron-right"></i>Cars </a></li>
                    <li><a href="products.php?cat1=2"><i class="icon-chevron-right"></i>Motor Bikes</a></li>
                    <li><a href="products.php?cat1=3"><i class="icon-chevron-right"></i>Cycles</a></li>
                    <li><a href="products.php?cat1=4"><i class="icon-chevron-right"></i>Trollers</a></li>
                    </ul>
               </li>
               <li class="subMenu"><a> Fashion & Beauty</a>
               <ul style="display:none">
                    <li><a href="products.php?cat1=5"><i class="icon-chevron-right"></i>Clothes </a></li>
                    <li><a href="products.php?cat1=6"><i class="icon-chevron-right"></i>Foot Wear </a></li>                                                            
                    <li><a href="products.php?cat1=7"><i class="icon-chevron-right"></i>Accessories</a></li>                                                           
                    <li><a href="products.php?cat1=8"><i class="icon-chevron-right"></i>Watches</a></li>                                                          
                                                                             
               </ul>
               </li>
               <li class="subMenu"><a>Electronic And Computers</a>
                    <ul style="display:none">
                    <li><a href="products.php?cat1=9"><i class="icon-chevron-right"></i>Computers & Laptops  </a></li>
					<li><a href="products.php?cat1=10"><i class="icon-chevron-right"></i>Cameras </a></li>    
                    <li><a href="products.php?cat1=11"><i class="icon-chevron-right"></i>Videos Games & Consoles</a></li>
                    <li><a href="products.php?cat1=12"><i class="icon-chevron-right"></i>TV-Video-Audio</a></li>                                                        
                                                                  
                                                                                
               </ul>
               </li>
               <li class="subMenu"><a>Mobiles & Tablets </a>
                   <ul style="display:none">
                   <li><a href="products.php?cat1=13"><i class="icon-chevron-right"></i>Mobile Phones </a></li>
                    <li><a href="products.php?cat1=14"><i class="icon-chevron-right"></i>Tablets </a></li>                                                         
                    <li><a href="products.php?cat1=15"><i class="icon-chevron-right"></i>Accessories</a></li>    
                    <li><a href="products.php?cat1=16"><i class="icon-chevron-right"></i>Gadgets</a></li>
               </ul>
               </li>
               <li class="subMenu"><a>Home & Furniture</a>
                    <ul style="display:none">
                    <li><a href="products.php?cat1=17"><i class="icon-chevron-right"></i>Furniture  </a></li>
                    <li><a href="products.php?cat1=18"><i class="icon-chevron-right"></i>Fridge-AC-Washing Machine</a></li>     
                    <li><a href="products.php?cat1=19"><i class="icon-chevron-right"></i>Home & Kitchen Appliances</a></li>
                    <li><a href="products.php?cat1=20"><i class="icon-chevron-right"></i>Other Household Items</a></li>                                                           
               </ul>
               </li>
            <!--   <li class="subMenu"><a>Real State</a>
                    <ul style="display:none">
                    <li><a href="products.php?cat1=21"><i class="icon-chevron-right"></i>Houses </a></li>
                    <li><a href="products.php?cat1=22"><i class="icon-chevron-right"></i>Appartments </a></li>                                                          
                    <li><a href="products.php?cat1=23"><i class="icon-chevron-right"></i>Lands & Plots</a></li>  
                    <li><a href="products.php?cat1=24"><i class="icon-chevron-right"></i>Shop-Offices</a></li>
                                                                                
               </ul>
               </li>
                    -->
               </ul>
          <br/>
    </div>
    <br/>
	<!-- Sidebar end=============================================== -->

		
		<div class="span9" style="margin-top:325px">
	    <ul class="breadcrumb" style="margin:-345px 0px 20px">
			<li><a href="index.php">Home</a> <span class="divider">/</span></li>
			<li class="active">Ads</li>

	    </ul>
<h5 style="text-align: center;"> 
<?php	    
function product($num,$conn)
{

 $query = " SELECT * FROM subcat WHERE ID = '$num'";
            $r=mysqli_query($conn,$query);
          // $result = $conn->query($query);
         $count = mysqli_num_rows($r);
         $result=mysqli_fetch_array($r,MYSQLI_ASSOC);
			         

 echo $_SESSION['username']; 
	echo ' You can view your personal ads here<small class="pull-right"> </small></h5>	
		<hr class="soft"/>




		<hr class="soft"/>
			
	<br class="clr"/>
	<div class="tab-content">
		<div class="tab-pane active" id="listView">

';
$num=$_SESSION['id'];
$ad=1;
$count=1;
	while( $ad<100 )
		{
			 


			// echo "$SubCat_id";		
			 $query = "SELECT Photos,TITLE,DESCRIPTION,PRICE,SubCat_id from ad where ID='$ad' AND USER_ID='$num' and STATUS=1";
			 $result = $conn->query($query);
			 $count = mysqli_num_rows($result);
			     
		 while($row = mysqli_fetch_assoc($result))
			  {
		
			            if ($count >0 )
			             {
			             
			               
			                  //echo $row["TITLE"]; 

							 echo  '
			 				<div class="row">	  
							<div class="span2">
							<img src="'.$row['Photos'].'" alt="image not loaded properly">
 
							</div>';
						
			         echo "<div class=\"span4\"><h3>", $row["TITLE"] ,"</h3><hr class=\"soft\"/>","<p>",
			                $row["DESCRIPTION"],"</p><br class=\"clr\"/></div><div class=\"span3 alignR\">
			                <form class=\"form-horizontal qtyFrm\">
							<h3> Rs:",$row["PRICE"],"</h3>";
						//	echo $ad;
				     echo "<a href=\"product_details.php?ad=$ad\" class=\"btn btn-large btn-primary\"> View details<i class=\"icon-zoom-in icon-white\"></i></a>
						    <br><br></form></div></div>";
			                }

			          		

		                	}
$ad++;
		}
}
if(isset($_GET['cat1']))
{
    $cat1 = $_GET['cat1'];
}
else
$cat1=1;
//echo $cat1;
switch ($cat1)
 {


	case 1:
	product($cat1,$conn);
	break;
	case 2:
	product($cat1,$conn);
	break;
	case 3:
	product($cat1,$conn);
	break;
	case 4:
	product($cat1,$conn);
	break;
	case 5:
	product($cat1,$conn);
	break;
	case 6:
	product($cat1,$conn);
	break;
	case 7:
	product($cat1,$conn);
	break;
	case 8:
	product($cat1,$conn);
	break;
	case 9:
	product($cat1,$conn);
	break;
	case 10:
	product($cat1,$conn);
	break;		
	case 11:
	product($cat1,$conn);
	break;
	case 12:
	product($cat1,$conn);
	break;
	case 13:
	product($cat1,$conn);
	break;
	case 14:
	product($cat1,$conn);
	break;
	case 15:
	product($cat1,$conn);
	break;
	case 16:
	product($cat1,$conn);
	break;
		case 17:
	product($cat1,$conn);
	break;
		case 18:
	product($cat1,$conn);
	break;
		case 19:
	product($cat1,$conn);
	break;
		case 20:
	product($cat1,$conn);
	break;
	default:
	break;
}


		                	?>



		

				  
				
	        <!--        								


	        <div class=\"row\"><div class=\"span2\">
					<img src=\"themes/images/products/1.jpg\" alt=\"\"/>
					<hr class="soft"/>
					<h5></h5>
					<p>
					
					
			   $count=1;
	 		   $query = "select DESCRIPTION from ad where ID=1";
	           $result = $conn->query($query);
	           $count = mysqli_num_rows($result);
	         
	                
	               if ($count >0) {
	               	 while($row = mysqli_fetch_assoc($result))
	               	 {
	                  echo $row["DESCRIPTION"]; 
	                }
	            }
	                else 
	                	echo "ma";

	                		  

				?>
					</p>
				
					
				</div>
				<div class="span3 alignR">
				<form class="form-horizontal qtyFrm">
				<h3> 
		</h3>
				
				<!--<label class="checkbox">
					<input type="checkbox">  Adds product to compair
				</label><br/>-->
			
	
						
		

		<!--yahan se hataaya taah block view ka code -->
		


			 

</div>
	</div>

	<!--	<div class="pagination">
				<ul>
				<li><a href="#">&lsaquo;</a></li>
				<li><a href="#">1</a></li>
				<li><a href="#">2</a></li>
				<li><a href="#">3</a></li>
				<li><a href="#">4</a></li>
				<li><a href="#">...</a></li>
				<li><a href="#">&rsaquo;</a></li>
				</ul>
				</div>-->
				<br class="clr"/>
	</div>
	</div>
	</div>

	<!-- MainBody End ============================= -->
	<!-- Footer ================================================================== -->
		<?php

	include_once 'footer.php';

	?>