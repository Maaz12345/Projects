
<?php
require_once 'connection.php';



$query="select max(id) as UID from user";
$result = $conn->query($query);
$count = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
$uid=$row["UID"]+1;



$query="select max(id) as AID from ad";
$result = $conn->query($query);
$count = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
$aid=$row["AID"]+1;


//image
error_reporting(E_ALL);
ini_set("display_errors",1);
$success = 0;
$fail = 0;
$imagearray=array();    
$uploads_dir = 'uploads';
mkdir($uploads_dir."/".$aid, 0700);
$uploads_dir =$uploads_dir."/".$aid;
$count = 1;
//echo $aid;
foreach ($_FILES["userfile"]["error"] as $key => $error) {
    if ($error == UPLOAD_ERR_OK) {
        $tmp_name = $_FILES["userfile"]["tmp_name"][$key];
        $name = $_FILES["userfile"]["name"][$key];
        $uploadfile = "$uploads_dir/$name";
        $ext = strtolower(substr($uploadfile,strlen($uploadfile)-3,3));
        if (preg_match("/(jpg|gif|png|bmp)/",$ext)){
         //   echo $count;
            
            $newfile = "$uploads_dir/".str_pad($count,2,'0',STR_PAD_LEFT).".".$ext;
            $imagearray[$count]=$newfile;
            $count++;
            if(move_uploaded_file($tmp_name, $newfile)){
                $success++;
            }else{
                echo "Couldn't move file: Error Uploading the file. Retry after sometime.\n";
                $fail++;
            }
        }else{
            echo "Invalid Extension.\n";
            $fail++;
        }
    }
}
//echo "<br> Number of files Uploaded:".$success;
//echo "<br> Number of files Failed:".$fail;
//image

$uname=mysqli_real_escape_string($conn,$_POST['inputname']);   
$country=$_POST['inputcountry'];
$state=$_POST['inputstate'];
$city=1;
$cat=isset($_POST['cat']) ? $_POST['cat'] : 0;
$title=mysqli_real_escape_string($conn,$_POST['title']);
$desc=mysqli_real_escape_string($conn,$_POST['aditionalInfo']);
$price=$_POST['inputprice'];



$brand=$_POST['brand'];
$km=$_POST['km'];
$year=$_POST['year'];
if ($_POST['fuel']==1)
    $fuel="Petrol";
else if ($_POST['fuel']==2)
    $fuel="Diesel";
else if ($_POST['fuel']==3)
    $fuel="CNG";


    $query= "SELECT `ID`,`NAME` FROM `fields` WHERE `SUBCAT_ID`=$cat";
    $result = $conn->query($query);
    $count = mysqli_num_rows($result);
    $row = mysqli_fetch_assoc($result);
    $FID=$row["ID"];
session_start();
if(isset($_SESSION['username']) && $_SESSION['loggedin']=="true"  )  
    {
       // echo "i am here";
     // echo $_SESSION['username'];
        $uid=$_SESSION['id'];
    }
    else
    {

        $ad1="INSERT INTO user (ID, ROLE,NAME, EMAIL,PASSWORD) VALUES (NULL,0,'$uname',NULL,NULL)";

        if ($conn->query($ad1) === TRUE) {
         //       echo "New record created successfully";
            } else {
           //     echo "Error: " . $ad1 . "<br>" . $conn->error;
            }
            session_destroy();
    }






$query= "SELECT max(ID) as MID from ad";
$result = $conn->query($query);
$count = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
$MID=$row["MID"];


$ad1="SET foreign_key_checks = 0";
if ($conn->query($ad1) === TRUE) {
           //     echo "New record created successfully";
            } else {
             //   echo "Error: " . $ad1 . "<br>" . $conn->error;
            }

        $MID=$MID+1;    
if ($cat==1 || $cat==4)
    {
 
        $ad1="INSERT INTO adshasfield (ID, AD_ID,FIELDS_ID, VALUE) VALUES (NULL,$MID,$FID,'$brand'),(NULL,$MID,$FID+1,'$year'),(NULL,$MID,$FID+2,'$km'),(NULL,$MID,$FID+3,'$fuel')";

    }
if ($cat==2)
{
    $ad1="INSERT INTO adshasfield (ID, AD_ID,FIELDS_ID, VALUE) VALUES (NULL,$MID,$FID,'$brand'),(NULL,$MID,$FID+1,'$year'),(NULL,$MID,$FID+2,'$km')";
}

if ($cat==3 || $cat==9 || $cat==10|| $cat==11 || $cat==12 || $cat==13 || $cat==14 || $cat==16 || $cat==18|| $cat==19)
{
     $ad1="INSERT INTO adshasfield (ID, AD_ID,FIELDS_ID, VALUE) VALUES (NULL,$MID,$FID,'$brand'),(NULL,$MID,$FID+1,'$year')";
}


if ($cat==5 || $cat==6 || $cat==7 || $cat==8 || $cat==15 || $cat==17 || $cat==20 )
{
        $ad1="INSERT INTO adshasfield (ID, AD_ID,FIELDS_ID, VALUE) VALUES (NULL,$MID,$FID,'$brand')";

}
else
{}

//mysqli_query($conn,$ad); 
if ($conn->query($ad1) === TRUE) {
            //    echo "New record created successfully";
            } else {
              //  echo "Error: " . $ad1 . "<br>" . $conn->error;
            }

$id=mysqli_fetch_array(mysqli_query($conn,"select max(ID) from ad"),MYSQLI_NUM);





    
$inputm=$_POST['inputmobile'];

//echo"$uid";
//echo "$cat";

$ad="SET foreign_key_checks = 0";
if ($conn->query($ad) === TRUE) {
       //         echo "New record created successfully";
            } else {
         //       echo "Error: " . $ad . "<br>" . $conn->error;
            }
$ad="INSERT INTO ad (ID, USER_ID,COUNTRY_ID, STATE_ID, CITY_ID, SubCat_id, TITLE, DESCRIPTION, PRICE,CONTACT_NO,Photos,Photos1,Photos2) VALUES (NULL,$uid,$country,$state,$city,$cat,'$title','$desc',$price,$inputm,'$imagearray[1]','$imagearray[2]','$imagearray[3]')";

//mysqli_query($conn,$ad); 
if ($conn->query($ad) === TRUE) {
         //       echo "New record created successfully";
            } else {
           // echo "Error: " . $ad . "<br>" . $conn->error;
            }

$id=mysqli_fetch_array(mysqli_query($conn,"select max(ID) from ad"),MYSQLI_NUM);



//print_r($_POST);
//echo " " ;
//echo $imagearray[1];
//echo " ";

//echo $imagearray[2];
//echo " ";
//echo $imagearray[3];

 header("Refresh:0;url=/index.php");
exit();


//echo $brand;
//echo $year;

//echo $km;

?>
