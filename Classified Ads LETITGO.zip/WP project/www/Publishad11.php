<?php

include_once 'header.php';

?>
<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
     <!-- Sidebar ================================================== -->
     <div id="sidebar" class="span3">
        
          <ul id="sideManu" class="nav nav-tabs nav-stacked">
          <label>Select the category please</label>
               <li class="subMenu open"><a> Vehicles</a>
                    <ul>
                    <li><a <class="active" href="publishad.php?cat=1"><i class="icon-chevron-right"></i>Cars </a></li>
                    <li><a href="publishad.php?cat=2"><i class="icon-chevron-right"></i>Motor Bikes</a></li>
                    <li><a href="publishad.php?cat=3"><i class="icon-chevron-right"></i>Vans </a></li>
                    <li><a href="publishad.php?cat=4"><i class="icon-chevron-right"></i>Trollers</a></li>
                    </ul>
               </li>
               <li class="subMenu"><a> Fashion & Beauty</a>
               <ul style="display:none">
                    <li><a href="publishad.php?cat=5"><i class="icon-chevron-right"></i>Clothes </a></li>
                    <li><a href="publishad.php?cat=6"><i class="icon-chevron-right"></i>Foot Wear </a></li>                                                            
                    <li><a href="publishad.php?cat=7"><i class="icon-chevron-right"></i>Accessories</a></li>                                                           
                    <li><a href="publishad.php?cat=8"><i class="icon-chevron-right"></i>Watches</a></li>                                                          
                                                                             
               </ul>
               </li>
               <li class="subMenu"><a>Electronic And Computers</a>
                    <ul style="display:none">
                    <li><a href="publishad.php?cat=9"><i class="icon-chevron-right"></i>Computers & Laptops  </a></li>
					<li><a href="publishad.php?cat=10"><i class="icon-chevron-right"></i>Cameras </a></li>    
                    <li><a href="publishad.php?cat=11"><i class="icon-chevron-right"></i>Videos Games & Consoles</a></li>
                    <li><a href="publishad.php?cat=12"><i class="icon-chevron-right"></i>TV-Video-Audio</a></li>                                                        
                                                                  
                                                                                
               </ul>
               </li>
               <li class="subMenu"><a>Mobiles & Tablets </a>
                   <ul style="display:none">
                   <li><a href="publishad.php?cat=13"><i class="icon-chevron-right"></i>Mobile Phones </a></li>
                    <li><a href="publishad.php?cat=14"><i class="icon-chevron-right"></i>Tablets </a></li>                                                         
                    <li><a href="publishad.php?cat=15"><i class="icon-chevron-right"></i>Accessories</a></li>    
                    <li><a href="publishad.php?cat=16"><i class="icon-chevron-right"></i>Gadgets</a></li>
               </ul>
               </li>
               <li class="subMenu"><a>Home & Furniture</a>
                    <ul style="display:none">
                    <li><a href="publishad.php?cat=17"><i class="icon-chevron-right"></i>Furniture  </a></li>
                    <li><a href="publishad.php?cat=18"><i class="icon-chevron-right"></i>Fridge-AC-Washing Machine</a></li>     
                    <li><a href="publishad.php?cat=19"><i class="icon-chevron-right"></i>Home & Kitchen Appliances</a></li>
                    <li><a href="publishad.php?cat=20"><i class="icon-chevron-right"></i>Other Household Items</a></li>                                                           
               </ul>
               </li>
               <li class="subMenu"><a>Real State</a>
                    <ul style="display:none">
                    <li><a href="publishad.php?cat=21"><i class="icon-chevron-right"></i>Houses </a></li>
                    <li><a href="publishad.php?cat=22"><i class="icon-chevron-right"></i>Appartments </a></li>                                                          
                    <li><a href="publishad.php?cat=23"><i class="icon-chevron-right"></i>Lands & Plots</a></li>  
                    <li><a href="publishad.php?cat=24"><i class="icon-chevron-right"></i>Shop-Offices</a></li>
                                                                                
               </ul>
               </li>
                    
               </ul>
          <br/>
    </div>
    <br/>
               <!--<div class="thumbnail">
                    <img src="themes/images/payment_methods.png" title="Bootshop Payment Methods" alt="Payments Methods">
                    <div class="caption">
                      <h5>Payment Methods</h5>
                    </div>
                 </div>-->
     
<!-- Sidebar end=============================================== -->
	<div class="span9"  style="margin-top:370px;">
    <ul class="breadcrumb" style="margin:-365px 0px 20px">
		<li><a href="index.php">Home</a> <span class="divider">/</span></li>
		<li class="active">Publish Ad</li>
    </ul>
	<h3> Publish Ad</h3>	
	<div class="well">
	

<div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Fields that are marked '*' are mandatory to be filled . Please be precise </strong> 
	 </div>	

		<h4>Ad Info</h4>

		

		
<script type="text/javascript">
$(document).ready(function(){
    $("input[type='car']").click(function(){
        var $fileUpload = $("input[type='file']");
        if (parseInt($fileUpload.get(0).files.length)>4){
         alert("You can only upload a maximum of 4 files");
        }
    });    
});​

</script>


<?php
		
$tt=<<<EOD
	<form class="control-group" action="processad.php" method="post" name="tt">
		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="title" placeholder="Your Ad title" required>
			</div>
		</div>
</form>		

EOD;
$car=<<<EOD
	

	<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post" >

		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="" name="title" placeholder="Your Ad title" required>
			</div>
		</div>

			<div class="control-group">
			<label class="control-label" for="brand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="brand" placeholder="Your Ad brand" required>
			</div>
		</div>
		
			<div class="control-group">
			<label class="control-label" for="year">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="year" placeholder="Year" required/>
			</div>
		</div>


		<div class="control-group">
			<label class="control-label" for="km">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="km" placeholder="Km" required/>
			</div>
		</div>

		
		

		<div class="control-group">
			<label class="control-label" for="fuel">Fuel Type<sup>*</sup></label>
			<div class="controls">
			  <select name="fuel" required>
				<option value="">-</option>
				<option value="1">Petrol</option><option value="2">Diesel</option><option value="3">CNG</option><option value="4">LPG</option></select>
			</div>
		</div>	


		<div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price" required/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" required>
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" required >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<div class="control-group">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name" required>
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone" required/> <span>Number currently in use</span>
			</div>
		</div>

	
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="cat" value="1">
				<input class="btn btn-large btn-success" type="submit" value="Publish"/>
			</div>
		</div>
		
</form>


EOD;

$motor=<<<EOD

	

	

			<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post">

		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="title" placeholder="Your Ad title">
			</div>
		</div>
		
					<div class="control-group">
			<label class="control-label" for="brand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="brand" placeholder="Your Ad brand">
			</div>
		</div>

			<div class="control-group">
			<label class="control-label" for="year">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="year" placeholder="Year"/>
			</div>
		</div>


		<div class="control-group">
			<label class="control-label" for="km">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="km" placeholder="Km"/>
			</div>
		</div>

		
		


		<div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price"/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" >
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<div class="control-group">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name">
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone"/> <span>Number currently in use</span>
			</div>
		</div>
		
	
	
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="cat" value="2">
				<input class="btn btn-large btn-success" type="submit" value="publish" onclick="submitForms()"/>
			</div>
		</div>
		
</form>


EOD;
$van=<<<EOD


			

	<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post">

		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="title" placeholder="Your Ad title">
			</div>
		</div>
		
					<div class="control-group">
			<label class="control-label" for="brand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="brand" placeholder="Your Ad brand">
			</div>
		</div>

			<div class="control-group">
			<label class="control-label" for="inputyear">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputyear" placeholder="Year"/>
			</div>
		</div>


		<div class="control-group">
			<label class="control-label" for="km">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="km" placeholder="Km"/>
			</div>
		</div>

		
		

		<div class="control-group">
			<label class="control-label" for="fuel">Fuel Type<sup>*</sup></label>
			<div class="controls">
			  <select name="fuel" >
				<option value="">-</option>
				<option value="1">Petrol</option><option value="2">Diesel</option><option value="3">CNG</option><option value="4">LPG</option></select>
			</div>
		</div>	


		<div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price"/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" >
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<div class="control-group">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name">
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone"/> <span>Number currently in use</span>
			</div>
		</div>
		
	
	
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="cat" value="3">
				<input class="btn btn-large btn-success"  type="submit" value="publish" onclick="submitForms()"/>
			</div>
		</div>
		
</form>

EOD;
$Sqft=<<<EOD
	<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post">

		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="title" placeholder="Your Ad title">
			</div>
		</div>

			<div class="control-group">
				<label class="control-label" for="Sqft">Sq/ft<sup>*</sup></label>
				<div class="controls">
				  <input type="text" id="Sqft" placeholder="Sq/ft"/>
				</div>
			</div>
	
				<div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price"/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" >
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<div class="control-group">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name">
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone"/> <span>Number currently in use</span>
			</div>
		</div>
		
	
	
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="cat" value="3">
				<input class="btn btn-large btn-success" type="submit" value="publish" onclick="submitForms()"/>
			</div>
		</div>
		
</form>



EOD;
$Sqft_room=<<<EOD
	<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post">

		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="title" placeholder="Your Ad title">
			</div>
		</div>

		<div class="control-group">
			<label class="control-label" for="Sqft">Sq/ft<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="Sqft" placeholder="Sq/ft"/>
			</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="Rooms">No.of Rooms<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="Rooms" placeholder="Rooms"/>
			</div>
		</div>

				<div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price"/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" >
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<div class="control-group">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name">
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone"/> <span>Number currently in use</span>
			</div>
		</div>
		
	
	
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="cat" value="3">
				<input class="btn btn-large btn-success" type="submit" value="publish" onclick="submitForms()"/>
			</div>
		</div>
		
</form>


EOD;
$computer_laptop=<<<EOD

<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post">

		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="title" placeholder="Your Ad title">
			</div>
		</div>

					<div class="control-group">
			<label class="control-label" for="brand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="brand" placeholder="Your Ad brand">
			</div>
		</div>

				<div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price"/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" >
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<div class="control-group">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name">
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone"/> <span>Number currently in use</span>
			</div>
		</div>
		
	
	
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="cat" value=9>
				<input class="btn btn-large btn-success" type="submit" value="publish" onclick="submitForms()"/>
			</div>
		</div>


</form>

EOD;



$troller=<<<EOD


			

<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post">

		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="title" placeholder="Your Ad title">
			</div>
		</div>
		
					<div class="control-group">
			<label class="control-label" for="brand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="brand" placeholder="Your Ad brand">
			</div>
		</div>

			<div class="control-group">
			<label class="control-label" for="inputyear">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputyear" placeholder="Year"/>
			</div>
		</div>


		<div class="control-group">
			<label class="control-label" for="km">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="km" placeholder="Km"/>
			</div>
		</div>

		
		

		<div class="control-group">
			<label class="control-label" for="fuel">Fuel Type<sup>*</sup></label>
			<div class="controls">
			  <select name="fuel" >
				<option value="">-</option>
				<option value="1">Petrol</option><option value="2">Diesel</option><option value="3">CNG</option><option value="4">LPG</option></select>
			</div>
		</div>	


		<div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price"/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" >
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<div class="control-group">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name">
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone"/> <span>Number currently in use</span>
			</div>
		</div>
		
	
	
	<div class="control-group">
			<div class="controls">
				
				<input type="hidden" name="cat" value="4">
				<input class="btn btn-large btn-success" type="submit" value="publish" onclick="submitForms()"/>
			</div>
		</div>
		
</form>


EOD;
$como=<<<EOD

<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post">

		<div class="control-group">
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="title" placeholder="Your Ad title">
			</div>
		</div>



				<div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price"/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" >
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>

<div class="control-group">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name">
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone"/> <span>Number currently in use</span>
			</div>
		</div>
		
	
	
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="email_create" value="1">
				<input type="hidden" name="is_new_customer" value="1">
				<input class="btn btn-large btn-success" type="submit" value="Publish" s"/>
			</div>
		</div>


</form>




EOD;





// submitForms = function(){
//     document.getElementById("form1").submit();
//     document.getElementById("form2").submit();
// }
// If your forms don't have IDs but have names:
function check()
{
	if(empty($_FILES['img']['name'][0]))
	{

		//echo "No Image Selected";
		//header("Refresh: 5;Location: Publishad.php");

	     //checking whether a single file uploaded or not
	     //if enters here means no file uploaded
	     //so if you want you may put a check/validation here to make file
	     //upload a must in your website
	}
	
	if(isset($_FILES['img']['name'][5]))
	{

		//echo "Max image upload reached";
		//header("Refresh: 5;Location: Publishad.php");

	     //checking whether 6 files uploaded or not
	     //so here you can put a check/validation to restrict user from
	     //uploading more than 5 files
	}
	echo "maaz";

}


$cat=$_GET['cat']; 

switch ($cat) {

	case 1:
		//echo $tt;

		echo $car;
		echo check();
		//echo $como;




	//	$year=isset($_POST['inputyear']) ? $_POST['inputyear'] : '';
 // $km = isset($_POST['km']) ? $_POST['km'] : '';
  //$fuel = isset($_POST['fuel']) ? $_POST['fuel'] : '';
//echo $year;
//echo $km;
//echo $fuel;

	
	
		break;
	
case 2:
	//echo $tt;
		echo $motor;
//echo $como;
		break;
	case 3:
//		echo $tt;
		echo $van;
//		echo $como;
		break;
	case 4:
//		echo $tt;
		echo $troller;
//		echo $como;

		break;
	
	case 5:
		echo $como;
		echo check();
		break;
	case 6:
		echo $como;
		echo check();
		break;
	case 7:
		echo $como;
		break;
	case 8:
		echo $como;
		break;

	case 9:
		echo $computer_laptop;
		break;
	case 10:
	echo $computer_laptop;
		break;
	case 11:
	echo $computer_laptop;
		break;
	case 12:
		echo $computer_laptop;	
		break;
	case 13:
		echo $computer_laptop;
		break;
	case 14:
		echo $computer_laptop;
		break;
	case 15:
		echo $como;
		break;
	case 16:
		echo $computer_laptop;
		break;
	/*
	case 5.1:
		echo $como;
		break;
	case 5.2:
		echo $computer_laptop;
		break;
	case 5.3:
		echo $como;
		break;
	case 5.4:
		echo $como;
		break;


	case 6.1:
		
		
		echo $Sqft_room;
		break;
	case 6.2:
		
		echo $Sqft_room;
		break;
	case 6.3:
		
		echo $Sqft;
		
		break;
	case 6.4:
		echo $Sqft;
		
		break;
*/

	default:
		break;

}


?>




</div>
</div>
</div>
</div>
</div>

<!-- MainBody End ============================= -->
<!-- Footer ================================================================== -->
	

	<?php

include_once 'footer.php'; 

?>
	$(document).ready(function() {
		$("#ab").click(function(eve) {
			alert("hi")
			eve.preventDefault();
			$("#Brand").css("display", "block");
		});
	});