<?php
include_once 'header.php';

      //execute the SQL query and return records
      //$sql = "SELECT * from ad inner join adshasfield on ad.ID=adshasfield.AD_ID inner join country on ad.COUNTRY_ID=country.ID inner join state on state.ID=ad.STATE_ID inner join city on city.ID=ad.CITY_ID" ;
	  $sql = "SELECT * FROM ad where STATUS=0";
	  $result = mysqli_query($conn, $sql);
	  
	  if (!$result) {
    echo "Could not successfully run ($sql) query from DB: " . mysql_error();
}

	if (mysqli_num_rows($result) == 0) {
    echo "No rows found, nothing to print so am exiting";
    //exit;
}
    
include_once 'sidebar.php';
?>
		
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div>
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Statistics</h1>
			</div>
		</div>
				
		
		<div style="background-color:#F0F8FF" class="row">
			<div class="col-lg-12">
				<div style="background-color:#F0F8FF" class="panel panel-default">
					<div style="background-color:#F0F8FF" class="panel-heading"><center><p><b><font size=6 face='charcoal' color='black'>Ads List</font></b></center></div>
					<div class="panel-body">
						<table data-toggle="table" data-url="tables/data1.json"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						<table border="5" width="100%" style= "background-color: #FFFFFF; color: #000000; margin: 0 auto;" >
						    <thead>
						    <tr>
								
								
								<th>Ad ID</th>
								<th>User ID</th>
								<th>Country ID</th>
								<th>Title</th>
								<th>Description</th>
								<th>Price</th>
								<th>Status</td>
							</tr>
						    </thead>
							<tbody>
							<?php
							  while($row = mysqli_fetch_assoc($result) ){
								echo
								"<tr>

								  <td><b>{$row["ID"]}</td>
								  <td><b>{$row["USER_ID"]}</td>
								  <td><b>{$row["COUNTRY_ID"]}</td>
								  <td><b>{$row["TITLE"]}</td>
								  <td><b>{$row["DESCRIPTION"]}</td>
								  <td><b>{$row["PRICE"]}</td>
								  <td><b>{$row["STATUS"]}</td>  
								</tr>\n";
							}
							?>
							</tbody>
						</table>
						
						<center><form method="post">
							<div class="control-group">
								<label class="control-label"></label>
								<div class="controls">
									<input class="textboxes"  type="text" name="input1" placeholder="   Enter Ad Id">
								</div>
							</div>
								<br><button type="submit" style="margin-left:20px" name="verify" class="btn btn-primary">Verify</button>
							</form></center>
							<?php
							if(isset($_POST['verify']))
							{
								$id = $_POST['input1'];
								$sql= "UPDATE ad set STATUS=1 where ID=$id";
								$result=mysqli_query($conn,$sql);	
								
							}
							else
							{}
						
							?>
						<!--/  mysqli_close($conn); ?> -->
					</div>
				</div>
			</div>
		</div><!--/.row-->
		
		
		<div style="background-color:#F0F8FF" class="row">
			<div class="col-lg-12">
				<div style="background-color:#F0F8FF" class="panel panel-default">
					<div style="background-color:#F0F8FF" class="panel-heading"><center><p><b><font size=6 face='charcoal' color='black'>Verified Ads</font></b></center></div>
					<div class="panel-body">
						<table data-toggle="table" data-url="tables/data1.json"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						<table border="5" width="100%" style= "background-color: #FFFFFF; color: #000000; margin: 0 auto;" >
						    <thead>
						    <tr>
								<th>Ad ID</th>
								<th>User ID</th>
								<th>Country ID</th>
								<th>Title</th>
								<th>Description</th>
								<th>Price</th>
								<th>Status</td>
							</tr>
						    </thead>
							<tbody>
							<?php
								  $sql = "SELECT * FROM ad where STATUS=1";
	  								$result = mysqli_query($conn, $sql);
								$count = mysqli_num_rows($result);
					 			while($row = mysqli_fetch_assoc($result) ){
								echo
								"<tr>

								  <td><b>{$row["ID"]}</td>
								  <td><b>{$row["USER_ID"]}</td>
								  <td><b>{$row["COUNTRY_ID"]}</td>
								  <td><b>{$row["TITLE"]}</td>
								  <td><b>{$row["DESCRIPTION"]}</td>
								  <td><b>{$row["PRICE"]}</td>
								  <td><b>{$row["STATUS"]}</td> 
								</tr>\n";
							  }
							?>
							</tbody>
						</table>
						
					
					</div>
				</div>
			</div>
		</div><!--/.row-->
		
		<!----------------------------------ADS VERIFIEDDDDDDD----------------------------------------------->
		<?php
		$sql = "SELECT * FROM user where ROLE=1";
	  $result = mysqli_query($conn, $sql);
		?>
		<div style="background-color:#F0F8FF" class="row">
			<div class="col-lg-12">
				<div style="background-color:#F0F8FF" class="panel panel-default">
					<div style="background-color:#F0F8FF" class="panel-heading"><center><p><b><font size=6 face='charcoal' color='black'>Registered Users</font></b></center></div>
					<div class="panel-body">
						<table border="5" width="100%" style= "background-color: #FFFFFF; color: #000000; margin: 0 auto;" >
						    <thead>
						    <tr>
								<th>User ID</th>
								<th>Name</th>
								<th>Email</th>
								<th>Password</th>
							</tr>
						    </thead>
							<tbody>
							<?php
							  while($row = mysqli_fetch_assoc($result) ){
								echo
								"<tr>
								  <td><b>{$row["ID"]}</td>
								  <td><b>{$row["NAME"]}</td>
								  <td><b>{$row["EMAIL"]}</td>
								  <td><b>{$row["PASSWORD"]}</td>
								</tr>\n";
							  }
							?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
						<?php mysqli_close($conn); ?>
							
</body>

</html>
