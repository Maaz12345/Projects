<html> 
<head> 
<script type="text/javascript" src="jquery-1.7.2.min.js"></script> 
<script type="text/javascript" src="functions.js"></script> 
</head> <body> <button id="btnAddd”>New</button> <table id="tblData">	
<thead> 
<tr> 
<th>Name</th> 
<th>Phone</th> 
<th>Email</th> 
<th></th> 
</tr> 
</thead> 
<tbody> 
</tbody> 
</table> 
</body> 
</html>

function Add(){ 
$("#tblData tbody").append( 
"<tr>"+ 
"<td><input type='text'/></td>"+ "
<td><input type='text'/></td>"+ "
<td><input type='text'/></td>"+ "
<td><img src='images/disk.png' class='btnSave'><img src='images/delete.png' class='btnDelete'/></td>"+ 
"</tr>"); 

$(".btnSave").bind("click", Save);	
$(".btnDelete").bind("click", Delete); }; 

};