<?php

require_once 'Mandrill.php';

class SendMandrillEmail {

    public static function EmailSendingFunction($From, $To, $ToName, $Subject, $FromName, $Body) {

        $mandrill = new Mandrill('XNhX2MallEn7M9t1V3Bbbw');

        try {

            $message = array(
                'subject' => $Subject,
                'html' => $Body,
                'from_email' => $From,
                'from_name' => $FromName,
                'to' => array(
                    array(
                        'email' => $To,
                        'name' => $ToName,
                        'type' => 'to'
                    )
                ),
            );

            return $result = $mandrill->messages->send($message);
        } catch (Mandrill_Error $e) {
            throw $e;
        }
    }

}

?>