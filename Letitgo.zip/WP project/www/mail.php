<?php

require_once "sendMail.php";

$mail = new SendMandrillEmail;

// EmailSendingFunction($From, $To, $ToName, $Subject, $FromName, $Body)

$Body = "Dear Khizar! Your DC has been called. Come to my office tomorrow";

$emailResult = $mail->EmailSendingFunction("abdul.saeed@nu.edu.pk", "k132064@nu.edu.pk", "M.Khizar", "DC Call", "Abdul Saeed", $Body);

?>