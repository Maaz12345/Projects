<?php

include_once 'header.php';
 
?>
<div id="carouselBlk">
	<div id="myCarousel" class="carousel slide">
		<div class="carousel-inner">
		  <div class="item active">
		  <div class="container">
			<a href="products.php"><img style="width:100%" src="themes/images/carousel/lo.jpg" alt="special offers"/></a>
			<div class="carousel-caption">
				  <h4>Second Thumbnail label</h4>
				  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
				</div>
		  </div>
		  </div>
		  <div class="item">
		  <div class="container">
			<a href="products.php"><img style="width:100%" src="themes/images/carousel/fo.jpg" alt=""/></a>
				<div class="carousel-caption"
				  <h4>Second Thumbnail label</h4>
				  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
				</div>
		  </div>
		  </div>
		  <div class="item">
		  <div class="container">
			<a href="products.php"><img src="themes/images/carousel/ko.jpg" alt=""/></a>
			<div class="carousel-caption">
				  <h4>Second Thumbnail label</h4>
				  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
				</div>
			
		  </div>
		  </div>
		   <div class="item">
		   <div class="container">
			<a href="products.php"><img src="themes/images/carousel/po.gif" alt=""/></a>
			<div class="carousel-caption">
				  <h4>Second Thumbnail label</h4>
				  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
				</div>
		   
		  </div>
		  </div>
		   <div class="item">
		   <div class="container">
			<a href="products.php"><img src="themes/images/carousel/5.png" alt=""/></a>
			<div class="carousel-caption">
				  <h4>Second Thumbnail label</h4>
				  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
			</div>
		  </div>
		  </div>
		   <div class="item">
		   <div class="container">
			<a href="products.php"><img src="themes/images/carousel/6.png" alt=""/></a>
			<div class="carousel-caption">
				  <h4>Second Thumbnail label</h4>
				  <p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
				</div>
		  </div>
		  </div>
		</div>
		<a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
		<a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
	  </div> 
</div>
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar start=============================================== -->

<!-- Sidebar end=============================================== -->
	<div class="span1" style="margin-left:120px;">
	</div>
	<div class="span9" >
		
		<h4>Categories </h4>
		
			  <ul class="thumbnails">
				<li class="span3">
				  <div class="thumbnail">
					<a  href="products.php"><img src="themes/images/products/6.jpg" alt=""/></a>
					<div class="caption">
					  <h5>Vehicles</h5>
					 
					 <!-- <h4 style="text-align:center"><a class="btn" href="product_details.php"> <i class="icon-zoom-in"></i></a></h4>-->
					 
					</div>
				  </div>
				</li>
				<li class="span3">
				  <div class="thumbnail">
					<a  href="products.php"><img src="themes/images/products/7.jpg" alt="" height="250" width="310"/></a>	
					<div class="caption">
					  <h5><br><br>Fashion & Beauty</h5>
					 <!-- <p> 
						Lorem Ipsum is simply dummy text. 
					  </p>-->
					
					</div>
				  </div>
				</li>
				<li class="span3">
				  <div class="thumbnail">
					<a  href="products.php"><img src="themes/images/products/8.jpg" alt="" height="80" width="180" /></a>
					<div class="caption">
					  <h5>Electronic & Computers </h5>
					 
					   
					</div>
				  </div>
				</li>
				<li class="span3">
				  <div class="thumbnail">
					<a  href="products.php"><img src="themes/images/products/9.jpg" alt=""  height="680" width="710"/></a>
					<div class="caption">	
					  <h5><br><br>Mobile & Tablets </h5>
						
					 
					</div>
				  </div>
				</li>
				<li class="span3">
				  <div class="thumbnail">
					<a  href="products.php"><img src="themes/images/products/10.jpg" alt="" height="100" width="190"/></a>
					<div class="caption">
					  <h5>Home & Furniture</h5>
				
					 
					</div>
				  </div>
				</li>
				<li class="span3">
				  <div class="thumbnail">
					<a  href="products.php"><img src="themes/images/products/11.jpg" alt=""height="580" width="1050"/></a>
					<div class="caption">
					  <h5><br><br><br>Real State</h5>
					 
					 
					</div>
				  </div>
				</li>
			  </ul>	

			   <form class="form-horizontal" action="loginproducts.php"  >
	<h4></h4>

	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="email_create" value="1">
				<input type="hidden" name="is_new_customer" value="1">
				<input class="btn btn-large btn-success" style="margin-left:30px;width:500px;height:50px" type="submit"  value="Edit Personal Ads" />
			</div>
		</div>
		</form>

	<form class="form-horizontal" action="manprofile.php"  >

	<h4></h4>
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="email_create" value="1">
				<input type="hidden" name="is_new_customer" value="1">
						<input class="btn btn-large btn-success" style="margin-left:30px;width:500px;height:50px" type="submit"  value="Manage Profile" />
			</div>
		</div>
</form>

 <form class="form-horizontal" action="login.php"  >
	<h4></h4>

	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="email_create" value="1">
				<input type="hidden" name="is_new_customer" value="1">
				<input class="btn btn-large btn-success" style="margin-left:30px;width:500px;height:50px" type="submit"  value="LogOut" />
			</div>
		</div>
		</form>
</div>
</div>
</div>
</div>



