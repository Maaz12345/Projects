<?php

//echo"login";
//if (isset($_POST['submit'])) {
    //echo "<script>alert(\"Login page still under construction\");</script>";
//echo"login1";
    $servername = "localhost";
	$username = "root";
	$password = "12345";
	$db= "mydb";

	// Create connection
	$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
        $bool = false;
    } else {
        $bool = true;
           // echo "<p>Connected successfully 11</p>"; 
    }


   
    

  //      echo"In if";

     
  $email = isset($_POST['inputEmail1']) ? $_POST['inputEmail1'] : '';
  $password = isset($_POST['inputPassword1']) ? $_POST['inputPassword1'] : '';

//if(isset($_POST['inputEmail1'])){$Email = $_POST['inputEmail1']; }

 // echo $email;
 //echo $_POST["inputEmail1"];
//if(isset($_POST['price'])){ $price = $_POST['price']; } 
//if(isset($_POST['description'])){ $description = $_POST['description']; } 
 
  //          $Email = $_POST["inputEmail1"];
    //        $Password1 = $_POST["inputPassword1"];

            $query = " SELECT * FROM user WHERE EMAIL = '$email' AND PASSWORD = '$password' ";
           $result = $conn->query($query);
         
           $count = mysqli_num_rows($result);
          if ($count==1)
          { 
            echo "<script>alert(\"successfull Login\");</script>";
        
            header("Refresh:3;url=../loginuser.php");
     	 }
     	
        else 
          {
           echo "wrong email or password ";
           header("Refresh:3;url=../login.php");
          }
//}
           
           ?>