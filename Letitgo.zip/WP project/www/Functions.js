function setSession() {
 
  
     var item = document.getElementById("topMenu");
        console.log(item);
     var child =document.getElementById("loginthis");
     console.log(child.firstChild);
    child.innerText="Log Out";    
    //child.removeAttribute("href");
    child.firstChild.setAttribute("href","/logout.php");

}
function checkSession(param){
    console.log("i am in check session ");
    console.log(param);
    if(param=="1")
        setSession();
     else if(param=="0")
        unDoSession();
}



function unDoSession(){
    
  
        
        var li = document.getElementById("login"); 
        //  li.innerText="Log In";   
        console.log(li);    
        //li.innerText="Log In/ Register";
        li.setAttribute("href","/login.php");


}