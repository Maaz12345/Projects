<?php
include 'header.php';
?>
<!--banner-->
<div class="banner">
	<div class="col-sm-3 banner-mat">
		<img class="img-responsive"	src="images/ba1.jpg" alt="">
	</div>
	<div class="col-sm-6 matter-banner">
	 	<div class="slider">
	    	<div class="callbacks_container">
	      		<ul class="rslides" id="slider">
	        		<li>
	          			<img src="images/11.jpg" alt="">
	       			 </li>
			 		 <li>
	          			<img src="images/22.jpg" alt="">   
	       			 </li>
					 <li>
	          			<img src="images/11.jpg" alt="">
	        		</li>	
	      		</ul>
	 	 	</div>
		</div>
	</div>
	<div class="col-sm-3 banner-mat">
		<img class="img-responsive" src="images/ba.jpg" alt="">
	</div>
	<div class="clearfix"> </div>
</div>
<!--//banner-->
<!--content-->
<div class="content">
	<div class="container">
		<div class="content-top">
			<a <class="active" href="index.php?cat=1">All   </a>/<a <class="active" href="index.php?cat=2">Fruits   </a>/<a <class="active" href="index.php?cat=3">Vegetables</a>
			
			<?php
			$all=<<<EOD
			<div class="content-top1">
				<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php?product_id=1" action="single.php">
							<img class="img-responsive" src="images/Green-Apple.jpeg" alt="" />
						</a>
						<h3><a href="single.php">Apple Green ہرے سیب</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/red-apple.png" alt="" />
						</a>
						<h3><a href="single.php">Apple Red لال سیب</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/chinaapple.jpg" alt="" />
						</a>
						<h3><a href="single.php">Apple China چائنا سیب</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/applegourd.jpg" alt="" />
						</a>
						<h3><a href="single.php">Apple Gourd ٹنڈے</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="clearfix"> </div>
			</div>
			
			<div class="content-top1">
				<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/banana.jpg" alt="" />
						</a>
						<h3><a href="single.php">Banana کیلے</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/beetroot.jpg" alt="" />
						</a>
						<h3><a href="single.php">Beetroot چکندر</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/bittergourd.jpg" alt="" />
						</a>
						<h3><a href="single.php">Bitter Gourd کریلے</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/cocumber.png" alt="" />
						</a>
						<h3><a href="single.php">Cocumber کھیرا</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="clearfix"> </div>
			</div>

			<div class="content-top1">
				<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/cabbage.jpg" alt="" />
						</a>
						<h3><a href="single.php">Cabbage بند گوبی</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/capsicum.jpg" alt="" />
						</a>
						<h3><a href="single.php">Capsicum شملہ مرچ</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/carrot.png" alt="" />
						</a>
						<h3><a href="single.php">Carrot گاجر</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/cauliflower.png" alt="" />
						</a>
						<h3><a href="single.php">Cauliflower پھول گوبی</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="clearfix"> </div>
			</div>	
		</div>
	</div>
</div>
EOD;
$fruits=<<<EOD
<div class="content-top1">
				<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/Green-Apple.jpeg" alt="" />
						</a>
						<h3><a href="single.php">Apple Green ہرے سیب</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/red-apple.png" alt="" />
						</a>
						<h3><a href="single.php">Apple Red لال سیب</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/chinaapple.jpg" alt="" />
						</a>
						<h3><a href="single.php">Apple China چائنا سیب</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/banana.jpg" alt="" />
						</a>
						<h3><a href="single.php">Banana کیلے</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="clearfix"> </div>
			</div>
EOD;
$vege=<<<EOD
<div class="content-top1">
				<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/applegourd.jpg" alt="" />
						</a>
						<h3><a href="single.php">Apple Gourd ٹنڈے</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/beetroot.jpg" alt="" />
						</a>
						<h3><a href="single.php">Beetroot چکندر</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/bittergourd.jpg" alt="" />
						</a>
						<h3><a href="single.php">Bitter Gourd کریلے</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/cocumber.png" alt="" />
						</a>
						<h3><a href="single.php">Cocumber کھیرا</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="clearfix"> </div>
			</div>
			
			<div class="content-top1">
				<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/cabbage.jpg" alt="" />
						</a>
						<h3><a href="single.php">Cabbage بند گوبی</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/capsicum.jpg" alt="" />
						</a>
						<h3><a href="single.php">Capsicum شملہ مرچ</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/carrot.png" alt="" />
						</a>
						<h3><a href="single.php">Carrot گاجر</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="col-md-3 col-md2">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="single.php">
							<img class="img-responsive" src="images/cauliflower.png" alt="" />
						</a>
						<h3><a href="single.php">Cauliflower پھول گوبی</a></h3>
						<div class="price">
								<h5 class="item_price">Rs: 300</h5>
								<a href="#" class="item_add">Add To Cart</a>
								<div class="clearfix"> </div>
						</div>
						
					</div>
				</div>	
			<div class="clearfix"> </div>
			</div>

					</div>
				</div>	
			<div class="clearfix"> </div>
			</div>	
		</div>
	</div>
</div>
EOD;


$cat=$_GET['cat']; 

switch ($cat) {

	case 1:
		echo $all;
		break;

	case 2:
		echo $fruits;	
		break;

	case 3:
		echo $vege;

	default:
		echo $all;
		break;

}
?>
</body>
</html>