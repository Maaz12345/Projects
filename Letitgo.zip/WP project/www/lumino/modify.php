<?php
include_once 'header.php';
?>

	<?php

      //execute the SQL query and return records
      //$sql = "SELECT * from ad inner join adshasfield on ad.ID=adshasfield.AD_ID inner join country on ad.COUNTRY_ID=country.ID inner join state on state.ID=ad.STATE_ID inner join city on city.ID=ad.CITY_ID" ;
	  $sql = "SELECT * FROM maincat ";
	  $result = mysqli_query($conn, $sql);
	  
	  if (!$result) {
    echo "Could not successfully run ($sql) query from DB: " . mysql_error();
}

	if (mysqli_num_rows($result) == 0) {
    echo "No rows found, nothing to print so am exiting";
    //exit;
}
    ?>
		
<?php
include_once 'sidebar.php';
?>
		
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Catalog</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div style="background-color:#F0F8FF" class="panel-heading"><center><p><b><font size=6 face='charcoal' color='black'>Main Category</font></b></center></div>
					<div class="panel-body">
						<table data-toggle="table" data-url="tables/data1.json"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						<table border="5" width="50%" style= "background-color: #FFFFFF; color: #000000; margin: 0 auto;" >
						    <thead>
						    <tr id="myTableRow">
								
								
								<th><center>ID</th>
								<th><center>Category</td>
							</tr>
						    </thead>
							<tbody>
							<?php
							  while($row = mysqli_fetch_assoc($result) ){
								echo
								"<tr>
								  <td><center><b>{$row["ID"]}</td>
								  <td><center><b>{$row["NAME"]}</td>
								</tr>\n";
							  }
							?>
							</tbody>
						</table>
						
							<center><form method="post">
							<div class="control-group">
								<label class="control-label"></label>
								<div class="controls">
									<input class="textboxes"  type="text" name="input1" placeholder="   Enter Category ID">
									<input class="textboxes"  type="text" name="input2" placeholder="  Enter Category Name">
								</div>
							</div>
								<br><button type="submit" style="margin-left:20px" name="delete" class="btn btn-primary">Delete</button>
								<button type="submit" style="margin-left:90px" name="insert" class="btn btn-primary">Insert</button></br>
							</form></center>
						
						
							<?php
							if(isset($_POST['delete']))
							{
								$id = $_POST['input1'];
								$sql= "DELETE from maincat where ID=$id";
								$result=mysqli_query($conn,$sql);	
								mysqli_close($conn);
							}
							else
							{
								
							}
							?>
							
							<?php
							if(isset($_POST['insert']))
							{
								$id = $_POST['input2'];
								$sql= "INSERT INTO maincat (ID, NAME) VALUES (NULL, '$id')";
								$result=mysqli_query($conn,$sql);
								mysqli_close($conn);
							}
							else
							{
								
							}
							?>
							
							<!--/Sub Category Queries?>-->
							
						
						<!--/  mysqli_close($conn); ?> -->
					</div>
				</div>
			</div>
		</div><!--/.row-->
		
		<?php
		//$sql = "SELECT subcat.ID,maincat.NAME,subcat.NAME FROM subcat,maincat on subcat.MAINCAT_ID=maincat.ID";
		$sql1 = "SELECT * FROM subcat";
		
		$result = mysqli_query($conn, $sql1);
		//echo mysql_fetch_row($result);
		?>
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div style="background-color:#F0F8FF" class="panel-heading"><center><p><b><font size=6 face='charcoal' color='black'>Sub Category</font></b></center></div>
					<div class="panel-body">
						<table border="5" width="50%" style= "background-color: #FFFFFF; color: #000000; margin: 0 auto;" >
						    <thead>
						    <tr>
								<th>ID</th>
								<th>Main Category</th>
								<th>Sub Category</td>
							</tr>
						    </thead>
							<tbody>
							<?php
							  while($row = mysqli_fetch_assoc($result) ){
								echo
								"<tr>
								  <td><b>{$row["ID"]}</td>
								  <td><b>{$row["MAINCAT_ID"]}</td>
								  <td><b>{$row["NAME"]}</td>
								</tr>\n";
							  }
							?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
							
</body>

</html>
