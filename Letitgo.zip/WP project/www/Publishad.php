<?php

include_once 'header.php';

?>
<!-- Header End====================================================================== -->
<head>
	<script src="http://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.js"></script>
    <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.min.js"></script>
   <script type="text/javascript">

 //  function set() {
   	// body...
 //  	console.log("i am here");	
  // 	$("#Brand").css("display", "none");
 
//  }
var Subcat=0;

	function cars(clicked_id)
	{
		document.getElementById("catvalue").value = clicked_id; 
		Subcat=clicked_id;
		
		if ((clicked_id=="1")  || (clicked_id=="4"))
		{	$("#Category").css("display", "none");
			$("#Title").css("display", "block");
			$("#Brand").css("display", "block");
			$("#Year").css("display", "block");
			$("#Km").css("display", "block");
			$("#Feul").css("display", "block");
			$("#Price").css("display", "block");
			$("#Country").css("display", "block");
			$("#State").css("display", "block");
			$("#Additional").css("display", "block");
			$("#Photos").css("display", "block");
			$("#Name").css("display", "block");
			$("#Mobile").css("display", "block");
			$("#Submit").css("display", "block");
		}	
		else if (clicked_id=="2")
		{

			$("#Category").css("display", "none");
			$("#Title").css("display", "block");
			$("#Brand").css("display", "block");
			$("#Year").css("display", "block");
			$("#Km").css("display", "block");
			document.getElementById("Feul").required = true;
			$("#Feul").css("display", "none");

			$("#Price").css("display", "block");
			$("#Country").css("display", "block");
			$("#State").css("display", "block");
			$("#Additional").css("display", "block");
			$("#Photos").css("display", "block");
			$("#Name").css("display", "block");
			$("#Mobile").css("display", "block");
			$("#Submit").css("display", "block");
		}
		else if (clicked_id=="3")
		{	$("#Category").css("display", "none");
			$("#Title").css("display", "block");
			$("#Brand").css("display", "block");
			$("#Year").css("display", "block");
			document.getElementById("Km").required = true;
			$("#Km").css("display", "none");
			document.getElementById("Feul").required = true;
			$("#Feul").css("display", "none");
			$("#Price").css("display", "block");
			$("#Country").css("display", "block");
			$("#State").css("display", "block");
			$("#Additional").css("display", "block");
			$("#Photos").css("display", "block");
			$("#Name").css("display", "block");
			$("#Mobile").css("display", "block");
			$("#Submit").css("display", "block");
		}	

		else if ((clicked_id=="5") || (clicked_id=="6") || (clicked_id=="7")|| (clicked_id=="8"))
		{

			$("#Category").css("display", "none");
			$("#Title").css("display", "block");
			$("#Brand").css("display", "block");
			document.getElementById("Year").required = true;
			$("#Year").css("display", "none");
			document.getElementById("Km").required = true;
			$("#Km").css("display", "none");
			document.getElementById("Feul").required = true;
			$("Feul").css("display","none");
			$("#Price").css("display", "block");
			$("#Country").css("display", "block");
			$("#State").css("display", "block");
			$("#Additional").css("display", "block");
			$("#Photos").css("display", "block");
			$("#Name").css("display", "block");
			$("#Mobile").css("display", "block");
			$("#Submit").css("display", "block");
		}
		else if ((clicked_id=="9") || (clicked_id=="10") || (clicked_id=="11")|| (clicked_id=="12")|| (clicked_id=="13") || (clicked_id=="14") || (clicked_id=="16"))
		{

			$("#Category").css("display", "none");
			$("#Title").css("display", "block");
			$("#Brand").css("display", "block");
			$("#Year").css("display", "block");
			document.getElementById("Km").required = true;
			$("#Km").css("display", "none");
			document.getElementById("Feul").required = true;
			$("Feul").css("display","none");
			$("#Price").css("display", "block");
			$("#Country").css("display", "block");
			$("#State").css("display", "block");
			$("#Additional").css("display", "block");
			$("#Photos").css("display", "block");
			$("#Name").css("display", "block");
			$("#Mobile").css("display", "block");
			$("#Submit").css("display", "block");
		}

		else if  (clicked_id=="15")
		{

			$("#Category").css("display", "none");
			$("#Title").css("display", "block");
			$("#Brand").css("display", "block");
			document.getElementById("Year").required = true;
			$("#Year").css("display", "none");
			document.getElementById("Km").required = true;
			$("#Km").css("display", "none");
			document.getElementById("Feul").required = true;
			$("Feul").css("display","none");
			$("#Price").css("display", "block");
			$("#Country").css("display", "block");
			$("#State").css("display", "block");
			$("#Additional").css("display", "block");
			$("#Photos").css("display", "block");
			$("#Name").css("display", "block");
			$("#Mobile").css("display", "block");
			$("#Submit").css("display", "block");
		}
		
else if ((clicked_id=="18") || (clicked_id=="19"))
		{

			$("#Category").css("display", "none");
			$("#Title").css("display", "block");
			$("#Brand").css("display", "block");
			$("#Year").css("display", "block");
			document.getElementById("Km").required = true;
			$("#Km").css("display", "none");
			document.getElementById("Feul").required = true;
			$("Feul").css("display","none");
			$("#Price").css("display", "block");
			$("#Country").css("display", "block");
			$("#State").css("display", "block");
			$("#Additional").css("display", "block");
			$("#Photos").css("display", "block");
			$("#Name").css("display", "block");
			$("#Mobile").css("display", "block");
			$("#Submit").css("display", "block");
		}

		else if ((clicked_id=="17") || (clicked_id=="20"))
		{

			$("#Category").css("display", "none");
			$("#Title").css("display", "block");
			$("#Brand").css("display", "block");
			document.getElementById("Year").required = true;
			$("#Year").css("display", "none");
			document.getElementById("Km").required = true;
			$("#Km").css("display", "none");
			document.getElementById("Feul").required = true;
			$("Feul").css("display","none");
			$("#Price").css("display", "block");
			$("#Country").css("display", "block");
			$("#State").css("display", "block");
			$("#Additional").css("display", "block");
			$("#Photos").css("display", "block");
			$("#Name").css("display", "block");
			$("#Mobile").css("display", "block");
			$("#Submit").css("display", "block");
		}
		else{$("#Category").css("display", "block");}
/*switch(clicked_id){
    case "1":
     $("#Brand").css("display", "block");
  	case "2":
  	$("#Year").css("display", "block");
   break;
    default:
    $("#Km").css("display", "block");
    
    }*/
   //$(window).on("load", cars);	

}
</script>


</head>
<body>
	
	<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
     <!-- Sidebar ================================================== -->
     <div id="sidebar" class="span3">
          <!--<div class="well well-small"><a id="myCart" href="product_summary.php"><img src="themes/images/ico-cart.png" alt="cart">3 Items in your cart  <span class="badge badge-warning pull-right">$155.00</span></a></div>-->
          <ul id="sideManu" class="nav nav-tabs nav-stacked">
          <label>Category</label>
               <li class="subMenu open"><a> Vehicles</a>
                    <ul>
                    <li><a <class="active" id ="1" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Cars </a></li>
                    <li><a id ="2" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Motor Bikes</a></li>
                    <li><a id ="3" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Cycles </a></li>
                    <li><a id ="4" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Trollers</a></li>
                    </ul>
               </li>
                <li class="subMenu"><a> Fashion & Beauty</a>
               <ul style="display:none">
                    <li><a id ="5" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Clothes </a></li>
                    <li><a id ="6" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Foot Wear </a></li>                                                            
                    <li><a  id ="7" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Accessories</a></li>                                                           
                    <li><a id ="8" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Watches</a></li>                                                          
                                                                             
               </ul>
               </li>
              
               <li class="subMenu"><a>Electronic And Computers</a>
                    <ul style="display:none">
                    <li><a id ="9" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Computers & Laptops  </a></li>
					<li><a id ="10" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Cameras </a></li>    
                    <li><a id ="11" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Videos Games & Consoles</a></li>
                    <li><a id ="12" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>TV-Video-Audio</a></li>                                                        
                                                                  
                                                                                
               </ul>
               </li>
               <li class="subMenu"><a>Mobiles & Tablets </a>
                   <ul style="display:none">
                   <li><a id ="13" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Mobile Phones </a></li>
                    <li><a id ="14" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Tablets </a></li>                                                         
                    <li><a id ="15" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Accessories</a></li>    
                    <li><a id ="16" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Gadgets</a></li>
               </ul>
               </li>
               <li class="subMenu"><a>Home & Furniture</a>
                    <ul style="display:none">
                    <li><a id ="17" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Furniture  </a></li>
                    <li><a id ="18" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Fridge-AC-Washing Machine</a></li>     
                    <li><a id ="19" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Home & Kitchen Appliances</a></li>
                    <li><a id ="20" href="#" onclick="cars(this.id);"><i class="icon-chevron-right"></i>Other Household Items</a></li>                                                           
               </ul>
               </li>
             
               </li>
               </ul>
          <br/>
    </div>
    <br/>
               
	<div class="span9"  style="margin-top:370px;">
    <ul class="breadcrumb" style="margin:-365px 0px 20px">
		<li><a href="index.php">Home</a> <span class="divider">/</span></li>
		<li class="active">Publish Ad</li>
    </ul>
	<h3> Publish Ad</h3>	
	<div class="well">
	
<div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Fields that are marked '*' are mandatory to be filled . Please be precise </strong> 
	 </div>	

		<h4>Ad Info</h4>
			<form enctype="multipart/form-data" class="form-horizontal"  id="myform" action="processad.php" method="post">

		
		<div id="Category" >
		<h5 style="text-align: center;"> Please Select Category From Sidebar</h5>
		</div>
		<div  id="Title" class="control-group"  style="display:none;"  >
			<label class="control-label" for="title">Title <sup>*</sup></label>
			<div class="controls">
			  <input  type="text" name="title"  placeholder="Your Ad title" required>
			</div>
		</div>
					
		<div id ="Brand"  class="control-group" style="display:none">
			<label   class="control-label"  for="brand">Brand <sup>*</sup></label>
			<div   class="controls" >
			  <input  type="text" name="brand" placeholder="Your Ad brand" >
			</div>
		</div>
	
			<div id ="Year" class="control-group"  style="display:none"> <!-- style="display:none;" -->
			<label class="control-label" for="year">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="year" placeholder="Year"/>
			</div>
		</div>


		<div id ="Km" class="control-group" style="display:none;">
			<label class="control-label" for="km">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="km" placeholder="Km"/>
			</div>
		</div>
	
		<div id ="Feul" class="control-group"style="display:none;">
			<label class="control-label" for="fuel">Fuel Type<sup>*</sup></label>
			<div class="controls">
			  <select name="fuel" >
				<option value="">-</option>
				<option value="1">Petrol</option><option value="2">Diesel</option><option value="3">CNG</option></select>
			</div>
		</div>	


		<div id="Price" class="control-group"style="display:none;">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price" required/><span><strong>Appropriate price<strong></span>
			</div>
		</div>
        	<div id="Country" class="control-group" style="display:none;">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" required>
			<option value="">-</option>
			<option value="1">Pakistan</option>
		</select>
			</div>
		</div>		

<div id="State"  class="control-group"style="display:none;">
			<label class="control-label" for="inputstate" >State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" required >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div id="Additional" class="control-group" style="display:none;">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<!--
<div id="Photos" class="control-group" style="display:none;">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input type="file" required="required" accept="image/*" multiple name="img[]" id="image" />
          </div>
</div>-->

<div id="Photos" class="control-group" style="display:none;">
			<label class="control-label" for="img[]">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
                 	Image1: <input name="userfile[]" type="file" required/><br />
					Image2: <input name="userfile[]" type="file" required /><br />
					Image3: <input name="userfile[]" type="file" required /><br />
          </div>
</div>

		<div id="Name" class="control-group" style="display:none;">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname"  pattern="[a-zA-Z]{1,}" title ="Only Letters Allowed " placeholder="Your Name" required="">
			</div>
</div>



		<div id="Mobile" class="control-group" style="display:none;">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile"  id="inputmobile" pattern="[0][3][0-9]{9}" title ="Please enter in this format 03XXXXXXXXX " placeholder="Mobile Phone"  maxlength="11"  required="" /> <span>Number currently in use</span>
			</div>
		</div>

	
		


	
	
	<div id="Submit" class="control-group" style="display:none;" >
			<div class="controls">
				<input id ="catvalue" type="hidden" name="cat" value="" >
				<input class="btn btn-large btn-success" type="submit" value="Publish" onclick="submitForms()"/>
			</div>
		</div>
		
</form>








</div>
</div>
</div>
</div>
</div>

</body>
<!-- MainBody End ============================= -->
<!-- Footer ================================================================== -->


	<?php

include_once 'footer.php'; 

?>
