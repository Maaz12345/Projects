<?php


    $servername = "localhost";
	$username = "root";
	$password = "";
	$db= "mydb";
  $GLOBALS['LoginUnsuc'] =1;

	// Create connection
	$conn = new mysqli($servername, $username, $password, $db);

if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
        $bool = false;
    } else {
        $bool = true;
           // echo "<p>Connected successfully 11</p>"; 
    }
     $_SESSION['username']="Guest";
     $_SESSION['id']=NULL;
     $_SESSION['loggedin']="false";
   //  $_SESSION['loggedin']=false;
  $email = isset($_POST['inputEmail1']) ? $_POST['inputEmail1'] : '';
  $password = isset($_POST['inputPassword1']) ? $_POST['inputPassword1'] : '';
            $query = " SELECT * FROM admin WHERE EMAIL = '$email' AND PASSWORD = '$password' ";
            $r=mysqli_query($conn,$query);
          // $result = $conn->query($query);
         $count = mysqli_num_rows($r);
         $result=mysqli_fetch_array($r,MYSQLI_ASSOC);
      
      //     print_r($result);
          if ($count==1)
          {
           header("Refresh:0;url=../lumino/index.php");
            exit();
          }
          
              $query = " SELECT * FROM user WHERE EMAIL = '$email' AND PASSWORD = '$password' ";
          $r=mysqli_query($conn,$query);
          // $result = $conn->query($query);
         $count = mysqli_num_rows($r);
         $result=mysqli_fetch_array($r,MYSQLI_ASSOC);
      
     //      print_r($result);
          if ($count==1)
          { 
           // echo "<script>alert(\"successfull Login\");</script>";
           session_start();
           //$_SESSION['check']=1;
        $_SESSION['loggedin']="true";  
            $_SESSION['id']=$result['ID'];
            $_SESSION['username'] = $result['NAME'];
           $_SESSION['email'] = $result['EMAIL'];
            $url="/index.php";
            header("Refresh:0;url=/Personalads.php");
            exit();
     	 }


       else if ($count==0 && isset($_POST['inputEmail1']) && isset($_POST['inputPassword1']))
          {   
              
            echo '<script>alert("***********************Unsuccessfull Login:********************\nPlease Enter Correct Password And Email");</script>';

        // window.close();
                 header("Refresh:0;url=/login.php");
                 exit();
          }

?>
  