<?php

include_once 'header.php';
 
?>
<!-- Header End====================================================================== -->
<div id="mainBody">
	<div class="container">
	<div class="row">
<!-- Sidebar ================================================== -->
     <!-- Sidebar ================================================== -->
     <div id="sidebar" class="span3">
          <!--<div class="well well-small"><a id="myCart" href="product_summary.php"><img src="themes/images/ico-cart.png" alt="cart">3 Items in your cart  <span class="badge badge-warning pull-right">$155.00</span></a></div>-->
          <ul id="sideManu" class="nav nav-tabs nav-stacked">
          <label>Select the category please</label>
               <li class="subMenu open"><a> Vehicles</a>
                    <ul>
                    <li><a <class="active" href="publishad.php?cat=1.1"><i class="icon-chevron-right"></i>Cars </a></li>
                    <li><a href="publishad.php?cat=1.2"><i class="icon-chevron-right"></i>Motor Bikes</a></li>
                    <li><a href="publishad.php?cat=1.3"><i class="icon-chevron-right"></i>Vans </a></li>
                    <li><a href="publishad.php?cat=1.4"><i class="icon-chevron-right"></i>Trollers</a></li>
                    </ul>
               </li>
               <li class="subMenu"><a> Fashion & Beauty</a>
               <ul style="display:none">
                    <li><a href="publishad.php?cat=2.1"><i class="icon-chevron-right"></i>Clothes </a></li>
                    <li><a href="publishad.php?cat=2.2"><i class="icon-chevron-right"></i>Foot Wear </a></li>                                                            
                    <li><a href="publishad.php?cat=2.3"><i class="icon-chevron-right"></i>Accessories</a></li>                                                           
                    <li><a href="publishad.php?cat=2.4"><i class="icon-chevron-right"></i>Watches</a></li>                                                          
                                                                             
               </ul>
               </li>
               <li class="subMenu"><a>Electronic And Computers</a>
                    <ul style="display:none">
                    <li><a href="publishad.php?cat=3.1"><i class="icon-chevron-right"></i>Computers & Laptops  </a></li>
					<li><a href="publishad.php?cat=3.2"><i class="icon-chevron-right"></i>Cameras </a></li>    
                    <li><a href="publishad.php?cat=3.3"><i class="icon-chevron-right"></i>Videos Games & Consoles</a></li>
                    <li><a href="publishad.php?cat=3.4"><i class="icon-chevron-right"></i>TV-Video-Audio</a></li>                                                        
                                                                  
                                                                                
               </ul>
               </li>
               <li class="subMenu"><a>Mobiles & Tablets </a>
                   <ul style="display:none">
                   <li><a href="publishad.php?cat=4.1"><i class="icon-chevron-right"></i>Mobile Phones </a></li>
                    <li><a href="publishad.php?cat=4.2"><i class="icon-chevron-right"></i>Tablets </a></li>                                                         
                    <li><a href="publishad.php?cat=4.3"><i class="icon-chevron-right"></i>Accessories</a></li>    
                    <li><a href="publishad.php?cat=4.4"><i class="icon-chevron-right"></i>Gadgets</a></li>
               </ul>
               </li>
               <li class="subMenu"><a>Home & Furniture</a>
                    <ul style="display:none">
                    <li><a href="publishad.php?cat=5.1"><i class="icon-chevron-right"></i>Furniture  </a></li>
                    <li><a href="publishad.php?cat=5.2"><i class="icon-chevron-right"></i>Fridge-AC-Washing Machine</a></li>     
                    <li><a href="publishad.php?cat=5.3"><i class="icon-chevron-right"></i>Home & Kitchen Appliances</a></li>
                    <li><a href="publishad.php?cat=5.4"><i class="icon-chevron-right"></i>Other Household Items</a></li>                                                           
               </ul>
               </li>
               <li class="subMenu"><a>Real State</a>
                    <ul style="display:none">
                    <li><a href="publishad.php?cat=6.1"><i class="icon-chevron-right"></i>Houses </a></li>
                    <li><a href="publishad.php?cat=6.2"><i class="icon-chevron-right"></i>Appartments </a></li>                                                          
                    <li><a href="publishad.php?cat=6.3"><i class="icon-chevron-right"></i>Lands & Plots</a></li>  
                    <li><a href="publishad.php?cat=6.4"><i class="icon-chevron-right"></i>Shop-Offices</a></li>
                                                                                
               </ul>
               </li>
                    
               </ul>
          <br/>
    </div>
    <br/>
               <!--<div class="thumbnail">
                    <img src="themes/images/payment_methods.png" title="Bootshop Payment Methods" alt="Payments Methods">
                    <div class="caption">
                      <h5>Payment Methods</h5>
                    </div>
                 </div>-->
     
<!-- Sidebar end=============================================== -->
	<div class="span9"  style="margin-top:370px;">
    <ul class="breadcrumb" style="margin:-365px 0px 20px">
		<li><a href="index.php">Home</a> <span class="divider">/</span></li>
		<li class="active">Publish Ad</li>
    </ul>
	<h3> Publish Ad</h3>	
	<div class="well">
	<!--
	<div class="alert alert-info fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div>
	<div class="alert fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply dummy</strong> text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div>
	 <div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Lorem Ipsum is simply</strong> dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s
	 </div> -->
	<form class="form-horizontal"   >
	<!--	<h4>Your personal information</h4>
		<div class="control-group">
		<label class="control-label">Title <sup>*</sup></label>
		<div class="controls">
		<select class="span1" name="days">
			<option value="">-</option>
			<option value="1">Mr.</option>
			<option value="2">Mrs</option>
			<option value="3">Miss</option>
		</select>
		</div>
		</div>
		<div class="control-group">
			<label class="control-label" for="inputFname1">First name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputFname1" placeholder="First Name">
			</div>
		 </div>
		 <div class="control-group">
			<label class="control-label" for="inputLnam">Last name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputLnam" placeholder="Last Name">
			</div>
		 </div>
		<div class="control-group">
		<label class="control-label" for="input_email">Email <sup>*</sup></label>
		<div class="controls">
		  <input type="text" id="input_email" placeholder="Email">
		</div>
	  </div>	  
	<div class="control-group">
		<label class="control-label" for="inputPassword1">Password <sup>*</sup></label>
		<div class="controls">
		  <input type="password" id="inputPassword1" placeholder="Password">
		</div>
	  </div>	  
		<div class="control-group">
		<label class="control-label">Date of Birth <sup>*</sup></label>
		<div class="controls">
		  <select class="span1" name="days">
				<option value="">-</option>
					<option value="1">1&nbsp;&nbsp;</option>
					<option value="2">2&nbsp;&nbsp;</option>
					<option value="3">3&nbsp;&nbsp;</option>
					<option value="4">4&nbsp;&nbsp;</option>
					<option value="5">5&nbsp;&nbsp;</option>
					<option value="6">6&nbsp;&nbsp;</option>
					<option value="7">7&nbsp;&nbsp;</option>
			</select>
			<select class="span1" name="days">
				<option value="">-</option>
					<option value="1">1&nbsp;&nbsp;</option>
					<option value="2">2&nbsp;&nbsp;</option>
					<option value="3">3&nbsp;&nbsp;</option>
					<option value="4">4&nbsp;&nbsp;</option>
					<option value="5">5&nbsp;&nbsp;</option>
					<option value="6">6&nbsp;&nbsp;</option>
					<option value="7">7&nbsp;&nbsp;</option>
			</select>
			<select class="span1" name="days">
				<option value="">-</option>
					<option value="1">1&nbsp;&nbsp;</option>
					<option value="2">2&nbsp;&nbsp;</option>
					<option value="3">3&nbsp;&nbsp;</option>
					<option value="4">4&nbsp;&nbsp;</option>
					<option value="5">5&nbsp;&nbsp;</option>
					<option value="6">6&nbsp;&nbsp;</option>
					<option value="7">7&nbsp;&nbsp;</option>
			</select>
		</div>
	  </div>
-->

<div class="alert alert-block alert-error fade in">
		<button type="button" class="close" data-dismiss="alert">×</button>
		<strong>Fields that are marked '*' are mandatory to be filled . Please be precise </strong> 
	 </div>	

		<h4>Ad Info</h4>

		<?php

		

		$como=<<<EOD

        <div class="control-group">
			<label class="control-label" name="inputprice">Price<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputprice" placeholder="Price"/><span></span>
			</div>
		</div>
        	<div class="control-group">
			<label class="control-label" for="inputcountry">Country<sup>*</sup></label>
			<div class="controls">
			<select name="inputcountry" >
				<option value="">-</option>
				<option value="1">Pakistan</option>
			</select>
			</div>
		</div>		

<div class="control-group">
			<label class="control-label" for="inputstate">State<sup>*</sup></label>
			<div class="controls">
			  <select name="inputstate" >
				<option value="">-</option>
				<option value="1">Sindh</option><option value="2">Punjab</option><option value="3">Balochistan</option><option value="4">KPK</option></select>
			</div>
		</div>	

		
		<div class="control-group">
			<label class="control-label" for="aditionalInfo">Description</label>
			<div class="controls">
			  <textarea name="aditionalInfo" id="aditionalInfo" cols="26" rows="5">Additional information</textarea>
			</div>
			</div>
		

<br>
<div class="control-group">
			<label class="control-label" for="inputphoto">Photos <sup>*   </sup></label>
            
               </label>
               <div class="controls">
               <input name="inputphoto" id="inputphoto" required="required" type="file">
          </div>
</div>


		<div class="control-group">
			<label class="control-label" for="inputname">Name <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputname" placeholder="Your Name">
			</div>
</div>



		<div class="control-group">
			<label class="control-label" for="inputmobile">Mobile Phone <sup>*</sup></label>
			<div class="controls">
			  <input type="text"  name="inputmobile" id="inputmobile" placeholder="Mobile Phone"/> <span></span>
			</div>
		</div>
		
	
	
	<div class="control-group">
			<div class="controls">
				<input type="hidden" name="email_create" value="1">
				<input type="hidden" name="is_new_customer" value="1">
				<input class="btn btn-large btn-success" type="submit" value="Submit" />
			</div>
		</div>	
EOD;
$tt=<<<EOD
		<div class="control-group">
			<label class="control-label" for="inputtitle">Title <sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputtitle" placeholder="Your Ad title">
			</div>
		</div>
		
EOD;
$car=<<<EOD
		<div class="control-group">
			<label class="control-label" for="inputbrand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputbrand" placeholder="Brand">
			</div>
		</div>	

		<div class="control-group">
			<label class="control-label" for="inputyear">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputyear" placeholder="Year"/>
			</div>
		</div>


<div class="control-group">
			<label class="control-label" for="inputkm">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" name="inputkm" placeholder="Km"/>
			</div>
		</div>

		
		

<div class="control-group">
			<label class="control-label" for="inputfuel">Fuel Type<sup>*</sup></label>
			<div class="controls">
			  <select name="inputfuel" >
				<option value="">-</option>
				<option value="1">Petrol</option><option value="2">Diesel</option><option value="3">CNG</option><option value="4">LPG</option></select>
			</div>
		</div>	



	



		<!--****************commenting
		<div class="control-group">
			<label class="control-label" for="address">Address<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="address" placeholder="Adress"/> <span>Street address, P.O. box, company name, c/o</span>
			</div>
		</div>
		-->
		<!-- ******************commenting
		<div class="control-group">
			<label class="control-label" for="address2">Address (Line 2)<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="address2" placeholder="Adress line 2"/> <span>Apartment, suite, unit, building, floor, etc.</span>
			</div>
		</div>
		-->
		
	
	



EOD;
$motor=<<<EOD


<div class="control-group">
			<label class="control-label" for="inputbrand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputbrand" placeholder="Brand">
			</div>
		</div>


		<div class="control-group">
			<label class="control-label" for="inputyear">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputyear" placeholder="Year"/>
			</div>
		</div>


<div class="control-group">
			<label class="control-label" for="inputkm">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputkm" placeholder="Km"/>
			</div>
		</div>

	





EOD;
$van=<<<EOD
         <div class="control-group">
			<label class="control-label" for="inputbrand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputbrand" placeholder="Brand">
			</div>
		</div>


		<div class="control-group">
			<label class="control-label" for="inputyear">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputyear" placeholder="Year"/>
			</div>
		</div>


<div class="control-group">
			<label class="control-label" for="inputkm">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputkm" placeholder="Km"/>
			</div>
		</div>

		
	

<div class="control-group">
			<label class="control-label" for="inputfuel">Fuel Type<sup>*</sup></label>
			<div class="controls">
			  <select id="inputfuel" >
				<option value="">-</option>
				<option value="1">Petrol</option><option value="2">Diesel</option><option value="3">CNG</option><option value="4">LPG</option></select>
			</div>
		</div>	





		<!--
		<div class="control-group">
			<label class="control-label" for="address">Address<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="address" placeholder="Adress"/> <span>Street address, P.O. box, company name, c/o</span>
			</div>
		</div>
		-->
		<!--<div class="control-group">
			<label class="control-label" for="address2">Address (Line 2)<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="address2" placeholder="Adress line 2"/> <span>Apartment, suite, unit, building, floor, etc.</span>
			</div>
		</div>
		-->
		

EOD;
$Brand=<<<EOD

<div class="control-group">
			<label class="control-label" for="inputbrand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputbrand" placeholder="Brand">
			</div>
		</div>
EOD;
$Sqft=<<<EOD

		<div class="control-group">
			<label class="control-label" for="Sqft">Sq/ft<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="Sqft" placeholder="Sq/ft"/>
			</div>
		</div>

EOD;
$Rooms=<<<EOD

		<div class="control-group">
			<label class="control-label" for="Rooms">No.of Rooms<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="Rooms" placeholder="Rooms"/>
			</div>
		</div>

EOD;
$troller=<<<EOD
        <div class="control-group">
			<label class="control-label" for="inputbrand">Brand <sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputbrand" placeholder="Brand">
			</div>
		</div>

		<div class="control-group">
			<label class="control-label" for="inputyear">Year<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputyear" placeholder="Year"/>
			</div>
		</div>


<div class="control-group">
			<label class="control-label" for="inputkm">Km's Driven<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="inputkm" placeholder="Km"/>
			</div>
		</div>

		

<div class="control-group">
			<label class="control-label" for="inputfuel">Fuel Type<sup>*</sup></label>
			<div class="controls">
			  <select id="inputfuel" >
				<option value="">-</option>
				<option value="1">Petrol</option><option value="2">Diesel</option><option value="3">CNG</option><option value="4">LPG</option></select>
			</div>
		</div>	




		<!--
		<div class="control-group">
			<label class="control-label" for="address">Address<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="address" placeholder="Adress"/> <span>Street address, P.O. box, company name, c/o</span>
			</div>
		</div>
		-->
		<!--<div class="control-group">
			<label class="control-label" for="address2">Address (Line 2)<sup>*</sup></label>
			<div class="controls">
			  <input type="text" id="address2" placeholder="Adress line 2"/> <span>Apartment, suite, unit, building, floor, etc.</span>
			</div>
		</div>
		-->
		
EOD;
$cat=$_GET['cat']; 

switch ($cat) {

	case 1.1:
		echo $tt;
		echo $car;
			echo $como;
	//	$year=isset($_POST['inputyear']) ? $_POST['inputyear'] : '';
 // $km = isset($_POST['inputkm']) ? $_POST['inputkm'] : '';
  //$fuel = isset($_POST['inputfuel']) ? $_POST['inputfuel'] : '';
//echo $year;
//echo $km;
//echo $fuel;

	
	
		break;
	
	case 1.2:
	echo $tt;
		echo $motor;
		echo $como;
		break;
	case 1.3:
		echo $tt;
		echo $van;
		echo $como;
		break;
	case 1.4:
		echo $tt;
		echo $troller;
		echo $como;

		break;
	
	case 2.1:
		echo $tt;
		echo $como;
		break;
	case 2.2:
		echo $tt;
		echo $como;
		break;
	case 2.3:
		echo $tt;
		echo $como;
		break;
	case 2.4:
		echo $tt;
		echo $como;
		break;

	case 3.1:
		echo $tt;
		echo $Brand;
		echo $como;
		
		break;
	case 3.2:
		echo $tt;
		echo $Brand;
		echo $como;
		
		break;
	case 3.3:
		echo $tt;
		echo $Brand;
		echo $como;
		
		break;
	case 3.4:
		echo $tt;
		echo $Brand;
		echo $como;
		
		break;

	
	case 4.1:
		echo $tt;
		echo $Brand;
		echo $como;
		
		break;
	case 4.2:
		echo $tt;
		echo $Brand;
		echo $como;
		
		break;
	case 4.3:
		echo $tt;
		echo $accessories;
		echo $como;
		
		break;
	case 4.4:
		echo $tt;
		echo $Brand;
		echo $como;
		
		break;
	
	case 5.1:
		echo $tt;
		//echo $furniture;
		echo $como;
		
		break;
	case 5.2:
		echo $tt;
		echo $Brand;
		echo $como;
		
		break;
	case 5.3:
		echo $tt;
		//echo $home;
		echo $como;
		
		break;
	case 5.4:
		echo $tt;
		//echo $other_home;
		echo $como;
		
		break;


	case 6.1:
		echo $tt;
		echo $Rooms;
		echo $Sqft;
		echo $como;

		break;
	case 6.2:
		echo $tt;
		echo $Rooms;
		echo $Sqft;
		echo $como;
		
		break;
	case 6.3:
		echo $tt;
		echo $Sqft;
		echo $como;
		break;
	case 6.4:
		echo $tt;
		echo $Sqft;
		echo $como;
		break;


	default:
		break;

}


?>



</form>
</div>
</div>
</div>
</div>
</div>

<!-- MainBody End ============================= -->
<!-- Footer ================================================================== -->
	

	<?php

include_once 'footer.php'; 

?>