<?php

include_once 'header.php';

?>
<!-- Header End====================================================================== -->
<div id="mainBody">
<div class="container">
<div class="row">
	
	<!-- Sidebar ================================================== -->
	<div id="sidebar" class="span3">
          <!--<div class="well well-small"><a id="myCart" href="product_summary.php"><img src="themes/images/ico-cart.png" alt="cart">3 Items in your cart  <span class="badge badge-warning pull-right">$155.00</span></a></div>-->
          <ul id="sideManu" class="nav nav-tabs nav-stacked">
          <label>Select the category please</label>
               <li class="subMenu open"><a> Vehicles</a>
                    <ul>
                    <li><a <class="active" href="products.php?cat1=1"><i class="icon-chevron-right"></i>Cars </a></li>
                    <li><a href="products.php?cat1=2"><i class="icon-chevron-right"></i>Motor Bikes</a></li>
                    <li><a href="products.php?cat1=3"><i class="icon-chevron-right"></i>Cycles</a></li>
                    <li><a href="products.php?cat1=4"><i class="icon-chevron-right"></i>Trollers</a></li>
                    </ul>
               </li>
               <li class="subMenu"><a> Fashion & Beauty</a>
               <ul style="display:none">
                    <li><a href="products.php?cat1=5"><i class="icon-chevron-right"></i>Clothes </a></li>
                    <li><a href="products.php?cat1=6"><i class="icon-chevron-right"></i>Foot Wear </a></li>                                                            
                    <li><a href="products.php?cat1=7"><i class="icon-chevron-right"></i>Accessories</a></li>                                                           
                    <li><a href="products.php?cat1=8"><i class="icon-chevron-right"></i>Watches</a></li>                                                          
                                                                             
               </ul>
               </li>
               <li class="subMenu"><a>Electronic And Computers</a>
                    <ul style="display:none">
                    <li><a href="products.php?cat1=9"><i class="icon-chevron-right"></i>Computers & Laptops  </a></li>
					<li><a href="products.php?cat1=10"><i class="icon-chevron-right"></i>Cameras </a></li>    
                    <li><a href="products.php?cat1=11"><i class="icon-chevron-right"></i>Videos Games & Consoles</a></li>
                    <li><a href="products.php?cat1=12"><i class="icon-chevron-right"></i>TV-Video-Audio</a></li>                                                        
                                                                  
                                                                                
               </ul>
               </li>
               <li class="subMenu"><a>Mobiles & Tablets </a>
                   <ul style="display:none">
                   <li><a href="products.php?cat1=13"><i class="icon-chevron-right"></i>Mobile Phones </a></li>
                    <li><a href="products.php?cat1=14"><i class="icon-chevron-right"></i>Tablets </a></li>                                                         
                    <li><a href="products.php?cat1=15"><i class="icon-chevron-right"></i>Accessories</a></li>    
                    <li><a href="products.php?cat1=16"><i class="icon-chevron-right"></i>Gadgets</a></li>
               </ul>
               </li>
               <li class="subMenu"><a>Home & Furniture</a>
                    <ul style="display:none">
                    <li><a href="products.php?cat1=17"><i class="icon-chevron-right"></i>Furniture  </a></li>
                    <li><a href="products.php?cat1=18"><i class="icon-chevron-right"></i>Fridge-AC-Washing Machine</a></li>     
                    <li><a href="products.php?cat1=19"><i class="icon-chevron-right"></i>Home & Kitchen Appliances</a></li>
                    <li><a href="products.php?cat1=20"><i class="icon-chevron-right"></i>Other Household Items</a></li>                                                           
               </ul>
               </li>
            <!--   <li class="subMenu"><a>Real State</a>
                    <ul style="display:none">
                    <li><a href="products.php?cat1=21"><i class="icon-chevron-right"></i>Houses </a></li>
                    <li><a href="products.php?cat1=22"><i class="icon-chevron-right"></i>Appartments </a></li>                                                          
                    <li><a href="products.php?cat1=23"><i class="icon-chevron-right"></i>Lands & Plots</a></li>  
                    <li><a href="products.php?cat1=24"><i class="icon-chevron-right"></i>Shop-Offices</a></li>
                                                                                
               </ul>
               </li>
                    -->
               </ul>
          <br/>
    </div>
    <br/>
    <?php

$ad = $_GET['ad'];
//echo $ad;
       $query = "select user.NAME AS UNAME,country.Name AS CONAME, state.Name AS STNAME, city.Name AS CINAME,ad.PHOTOS AS image,ad.PHOTOS1 AS image1,ad.PHOTOS2 AS image2, ad.CONTACT_NO , ad.DESCRIPTION,ad.TITLE,ad.PRICE from ad, country, state,user, city where ad.USER_ID=user.ID and ad.COUNTRY_ID=country.ID and ad.STATE_ID=state.ID and ad.CITY_ID=city.ID and ad.ID='$ad'";
       $result = $conn->query($query);
       $count = mysqli_num_rows($result);
             $row = mysqli_fetch_assoc($result); 
//echo $count;          
          
echo '

<!-- Sidebar end=============================================== -->
	<div class="span9" style="margin-top:325px">
    <ul class="breadcrumb" style="margin:-345px 0px 20px">
    <li><a href="index.php">Home</a> <span class="divider">/</span></li>
    <li><a href="products.php">AD</a> <span class="divider">/</span></li>
    <li class="active">AD Details</li>
    </ul>	
   
		<div class="row">	  
			<div id="gallery" class="span3">
            <a href="'.$row['image'].'" title="Product">
				<img src="'.$row['image'].'" style="width:100%" style="height:100%" alt="Fuji1film FinePix S2950 Digital Camera"/>
            </a>
			<div id="differentview" class="moreOptopm carousel slide">
                <div class="carousel-inner">
                  <div class="item active">
                   <a href="'.$row['image1'].'"> <img style="width:45%" src="'.$row['image1'].'" alt=""/></a>
                     <a href="'.$row['image2'].'"> <img style="width:45%" src="'.$row['image2'].'" alt=""/></a>                
                  </div>
                  
                </div>
     
              </div>
                
			  
			 <div class=\"btn-toolbar\">
			  <div class=\"btn-group\">
				<span class=\"btn\"><i class=\"icon-envelope\"></i></span>
				<span class=\"btn\" ><i class=\"icon-print\"></i></span>
				<span class=\"btn\" ><i class=\"icon-zoom-in\"></i></span>
				<span class=\"btn\" ><i class=\"icon-star\"></i></span>
				<span class=\"btn\" ><i class=\" icon-thumbs-up\"></i></span>
				<span class=\"btn\" ><i class=\"icon-thumbs-down\"></i></span>
			  </div>
			</div>
			</div>';



				echo" <div class=\"span6\">
				<h3>" ,$row["TITLE"], "</h3>
				<h5><small>",$row["CONAME"],"--",$row["STNAME"],"--",$row["CINAME"],"</small></h5>
				<h5><hr class=\"soft\"/>Name--",$row["UNAME"]," 
				<br>Contact--No :", $row["CONTACT_NO"],"
				<hr class=\"soft\"/></h5>
				<h4>DESCRIPTION:<h5>",$row["DESCRIPTION"],"</h5></h4>
				</div> ";
$count1=1;
		    $PRICE=$row['PRICE'];
			ECHO "<div class=\"span9\">
            <ul id=\"productDetail\" class=\"nav nav-tabs\">
              <li class=\"active\"><a href=\"#home\" data-toggle=\"tab\">Product Details</a></li>
             
            </ul>
            <div id=\"myTabContent\" class=\"tab-content\">
              <div class=\"tab-pane fade active in\" id=\"home\">
			  <h4>Product Information</h4>
                <table class=\"table table-bordered\">
				<tbody>
				<tr class=\"techSpecRow\"><th colspan=\"2\">Product Details</th></tr>";
			
          $query="select NAME from fields where SUBCAT_ID=(SELECT SUBCAT_ID from ad where ID='$ad')";
      $result = $conn->query($query);
      $count = mysqli_num_rows($result);
 $solutions=array();     
 $solutionss=array();     
 
//echo $NAME;
//echo $FID;
//Echo $SID;

$count1=0;
			 WHILE ($row = mysqli_fetch_assoc($result))
			        {$solutions[]=$row['NAME'];}
      $query1="select value from adshasfield where AD_ID='$ad'";
      $result1 = $conn->query($query1);
      $count2 = mysqli_num_rows($result1); 

			WHILe ($row1 = mysqli_fetch_assoc($result1))
      {$solutionss[]=$row1['value'];}
			/*				
  			*/

        for ($i=0;$i<count($solutions);$i++)
				{

          ECHO '<tr class="techSpecRow"><td class="techSpecTD1">';
          echo $solutions[$i];
          echo ':</td><td class="techSpecTD2">';
          echo $solutionss[$i];
          echo '</td></tr>';
     }  
# code...
		//	echo count($solutions);
     // echo count($solutionss);
			ECHO "<tr class=\"techSpecRow\"><td class=\"techSpecTD1\">Price:</td><td class=\"techSpecTD2\">",$PRICE,"</td></tr>";
	ECHO"</tbody>
				</table>    
				</div>
		</div>
          </div>" ;

?>
			

	</div>
</div>
</div> </div>
</div>
<!-- MainBody End ============================= -->
<!-- Footer ================================================================== -->
	<?php

include_once 'Footer.php';

?>