<?php
require_once 'connection.php';
?>

<?php
if(isset($_POST['submit']))
{
	$q1= $_POST["name"];
	$q2= $_POST["contact"];
	$q3= $_POST["address"];
	$q4= $_POST["AName"];
	$q5= $_POST["CName"];
	$q6= $_POST["description"];	

$sql = "SELECT Id from area where AName='$q4'";
$result = mysqli_query($conn, $sql);
$row=mysqli_fetch_assoc($result);
$q7= $row['Id'];
$sql = "SELECT Id from category where CName='$q5'";
$result = mysqli_query($conn, $sql);
$row=mysqli_fetch_assoc($result);
$q8= $row['Id'];

$sql= "INSERT INTO place (Name,Descrip,Address,Contact,Category_Id,Area_Id) values ('$q1','$q6','$q3','$q2',$q8,$q7)";

	mysqli_query($conn,$sql);
	//<script type="Society Created/javascript">;
	//echo "<script>alert('Success!');</script>";
	
	echo "Successfully Submited";
	echo "<script>setTimeout(\"location.href = 'index.php';\",1500);</script>";
	//header("Location:index.php");
	
}

?>