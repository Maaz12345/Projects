
  <footer>
    <div class="footer-section ">
      <div class="container">
        <div class="social pull-left">
          <p><i class="fa fa-phone"></i>0312-2269496 <i class="fa fa-envelope-o"></i>Support@karachiplaces.com</p>
        </div>
        <div class="navigation">
          <ul class="pull-right">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="testimonial.php">Testimonial</a></li>
            <li><a href="contact.php">Contact</a></li>
          </ul>
        </div> 
      </div>
    </div>
    <div class="footer-bottom">
      <div class="container">
        <div class="social pull-left">
          <p>&copy; copyright www.searchkarachi.com, 2015. Developed By <a href="https://www.facebook.com/kodikaspk/">Kodikas</a></p>
        </div>
        <div class="navigation">
          <ul class="pull-right">
              <li><a href="#"> <i class="fa fa-2x fa-facebook"></i></a></li>
              <li><a href="#"><i class="fa fa-2x fa-twitter"></i></a></li>
              <li><a href="#"><i class="fa fa-2x fa-pinterest"></i></a></li>
            </ul>
        </div> 
      </div>
    </div>     
  </footer>

	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
    <script src="assets/js/modernizr-latest.js"></script> 
    <script type='text/javascript' src='assets/js/jquery.min.js'></script>
    <script type='text/javascript' src='assets/js/jquery.mobile.customized.min.js'></script>
    <script type='text/javascript' src='assets/js/jquery.easing.1.3.js'></script> 
    <script type='text/javascript' src='assets/js/camera.min.js'></script> 
    <script src="assets/js/bootstrap.min.js"></script> 
    
    <script>
		jQuery(function(){
			
			jQuery('#camera_wrap_4').camera({
                transPeriod: 500,
                time: 3000,
				height: '600',
				loader: 'false',
				pagination: true,
				thumbnails: false,
				hover: false,
                playPause: false,
                navigation: false,
				opacityOnGrid: false,
				imagePath: 'assets/images/'
			});

		});
      
	</script>
    
</body>
</html>